# MyGate Website

## Structure
- `backend/` — Spring Boot backend + embedded frontend (port 8080)
- `backend/src/main/resources/static/` — Web dashboards (served at http://localhost:8080)

## Requirements
- Java 17+
- Maven 3.8+

## Build & Run
```
cd backend
mvn clean package -DskipTests
java -jar target/mygate.jar
```

## Default Login Credentials
| Role     | Email                  | Password     |
|----------|------------------------|--------------|
| Admin    | admin@mygate.com       | admin123     |
| Guard    | guard@mygate.com       | guard123     |
| Resident | resident@mygate.com    | resident123  |
| Staff    | staff@mygate.com       | staff123     |
| Maid     | maid@mygate.com        | maid123      |

## Dashboard URLs (after server starts)
- Landing: http://localhost:8080/index.html
- Admin:    http://localhost:8080/admin.html
- Resident: http://localhost:8080/resident.html
- Guard:    http://localhost:8080/guard.html
- Staff:    http://localhost:8080/staff.html
- Maid:     http://localhost:8080/maid.html
- H2 DB:    http://localhost:8080/h2-console
