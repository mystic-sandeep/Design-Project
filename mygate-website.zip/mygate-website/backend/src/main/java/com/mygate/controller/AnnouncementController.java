package com.mygate.controller;

import com.mygate.entity.Announcement;
import com.mygate.repository.AnnouncementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/announcements")
public class AnnouncementController {

    @Autowired
    private AnnouncementRepository announcementRepo;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

    private static final Map<String, String> CATEGORY_EMOJI = Map.of(
        "festival", "🎉",
        "celebration", "🥳",
        "maintenance", "🔧",
        "emergency", "🚨",
        "general", "📢",
        "holiday", "🌟",
        "event", "🎊",
        "wishes", "✨"
    );

    @GetMapping
    public ResponseEntity<?> getAll(@RequestParam(required = false) String category) {
        List<Announcement> list = category != null
            ? announcementRepo.findByCategoryOrderByCreatedAtDesc(category)
            : announcementRepo.findAllByOrderByPinnedDescCreatedAtDesc();
        return ResponseEntity.ok(Map.of("success", true,
            "data", Map.of("announcements", list.stream().map(this::toMap).collect(Collectors.toList()))));
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Map<String, Object> body) {
        String title = (String) body.get("title");
        if (title == null || title.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "title required"));
        }
        String category = ((String) body.getOrDefault("category", "general")).toLowerCase();
        String emoji = CATEGORY_EMOJI.getOrDefault(category, "📢");
        if (body.containsKey("emoji")) emoji = (String) body.get("emoji");

        Announcement a = new Announcement();
        a.setTitle(title);
        a.setMessage((String) body.getOrDefault("message", ""));
        a.setCategory(category);
        a.setPostedBy((String) body.getOrDefault("postedBy", "Admin"));
        a.setEmoji(emoji);
        a.setPinned(Boolean.TRUE.equals(body.get("pinned")));
        announcementRepo.save(a);
        return ResponseEntity.ok(Map.of("success", true, "message", "Announcement posted", "data", toMap(a)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        announcementRepo.deleteById(id);
        return ResponseEntity.ok(Map.of("success", true, "message", "Announcement deleted"));
    }

    private Map<String, Object> toMap(Announcement a) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", a.getId());
        m.put("title", a.getTitle());
        m.put("message", a.getMessage() != null ? a.getMessage() : "");
        m.put("category", a.getCategory() != null ? a.getCategory() : "general");
        m.put("postedBy", a.getPostedBy() != null ? a.getPostedBy() : "Admin");
        m.put("emoji", a.getEmoji() != null ? a.getEmoji() : "📢");
        m.put("pinned", a.isPinned());
        m.put("createdAt", a.getCreatedAt() != null ? a.getCreatedAt().format(FMT) : "");
        return m;
    }
}
