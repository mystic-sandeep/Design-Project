package com.mygate.repository;

import com.mygate.entity.MaintenanceAlert;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MaintenanceAlertRepository extends JpaRepository<MaintenanceAlert, Long> {
    List<MaintenanceAlert> findAllByOrderByCreatedAtDesc();
}
