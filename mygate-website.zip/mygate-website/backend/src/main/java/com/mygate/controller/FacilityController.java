package com.mygate.controller;

import com.mygate.entity.FacilityBooking;
import com.mygate.repository.FacilityBookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/facilities")
public class FacilityController {

    @Autowired
    private FacilityBookingRepository facilityRepo;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

    @GetMapping
    public ResponseEntity<?> getAll(@RequestParam(required = false) String status) {
        List<FacilityBooking> list = status != null
            ? facilityRepo.findByStatusOrderByCreatedAtDesc(status)
            : facilityRepo.findAllByOrderByCreatedAtDesc();
        return ResponseEntity.ok(Map.of("success", true,
            "data", Map.of("bookings", list.stream().map(this::toMap).collect(Collectors.toList()))));
    }

    @GetMapping("/by-flat/{flat}")
    public ResponseEntity<?> getByFlat(@PathVariable String flat) {
        List<FacilityBooking> list = facilityRepo.findByResidentFlatOrderByCreatedAtDesc(flat);
        return ResponseEntity.ok(Map.of("success", true,
            "data", Map.of("bookings", list.stream().map(this::toMap).collect(Collectors.toList()))));
    }

    @PostMapping
    public ResponseEntity<?> createBooking(@RequestBody Map<String, Object> body) {
        String facilityName = (String) body.get("facilityName");
        if (facilityName == null || facilityName.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "facilityName required"));
        }
        FacilityBooking b = new FacilityBooking();
        b.setFacilityName(facilityName);
        b.setFacilityType((String) body.getOrDefault("facilityType", "Other"));
        b.setResidentName((String) body.getOrDefault("residentName", "Resident"));
        b.setResidentFlat((String) body.getOrDefault("residentFlat", ""));
        b.setResidentPhone((String) body.getOrDefault("residentPhone", ""));
        b.setPurpose((String) body.getOrDefault("purpose", ""));
        b.setBookingDate((String) body.getOrDefault("bookingDate", ""));
        b.setTimeSlot((String) body.getOrDefault("timeSlot", ""));
        Object guests = body.get("expectedGuests");
        if (guests != null) {
            try { b.setExpectedGuests(Integer.parseInt(guests.toString())); } catch (Exception ignored) {}
        }
        b.setStatus("pending");
        facilityRepo.save(b);
        return ResponseEntity.ok(Map.of("success", true, "message", "Facility booking request submitted. Awaiting admin approval.", "data", toMap(b)));
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateStatus(@PathVariable Long id, @RequestBody Map<String, String> body) {
        Optional<FacilityBooking> opt = facilityRepo.findById(id);
        if (opt.isEmpty()) return ResponseEntity.status(404).body(Map.of("success", false, "error", "Booking not found"));
        FacilityBooking b = opt.get();
        b.setStatus(body.getOrDefault("status", b.getStatus()));
        if (body.containsKey("adminNote")) b.setAdminNote(body.get("adminNote"));
        b.setReviewedAt(LocalDateTime.now());
        facilityRepo.save(b);
        return ResponseEntity.ok(Map.of("success", true, "message", "Booking " + b.getStatus(), "data", toMap(b)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        facilityRepo.deleteById(id);
        return ResponseEntity.ok(Map.of("success", true, "message", "Booking deleted"));
    }

    private Map<String, Object> toMap(FacilityBooking b) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", b.getId());
        m.put("facilityName", b.getFacilityName());
        m.put("facilityType", b.getFacilityType() != null ? b.getFacilityType() : "");
        m.put("residentName", b.getResidentName() != null ? b.getResidentName() : "");
        m.put("residentFlat", b.getResidentFlat() != null ? b.getResidentFlat() : "");
        m.put("residentPhone", b.getResidentPhone() != null ? b.getResidentPhone() : "");
        m.put("purpose", b.getPurpose() != null ? b.getPurpose() : "");
        m.put("bookingDate", b.getBookingDate() != null ? b.getBookingDate() : "");
        m.put("timeSlot", b.getTimeSlot() != null ? b.getTimeSlot() : "");
        m.put("expectedGuests", b.getExpectedGuests());
        m.put("status", b.getStatus() != null ? b.getStatus() : "pending");
        m.put("adminNote", b.getAdminNote() != null ? b.getAdminNote() : "");
        m.put("createdAt", b.getCreatedAt() != null ? b.getCreatedAt().format(FMT) : "");
        m.put("reviewedAt", b.getReviewedAt() != null ? b.getReviewedAt().format(FMT) : "");
        return m;
    }
}
