package com.mygate.controller;

import com.mygate.entity.StaffMember;
import com.mygate.repository.StaffRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.time.LocalDate;

@RestController
@RequestMapping("/api/v2/staff")
public class StaffCheckinController {

    @Autowired
    private StaffRepository staffRepository;

    private static final DateTimeFormatter FMT =
        DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm a");

    @PostMapping("/check-in")
    public ResponseEntity<?> checkIn(
            HttpServletRequest req,
            @RequestBody(required = false) Map<String, String> body) {

        String name = body != null && body.get("name") != null && !body.get("name").isBlank()
            ? body.get("name").trim() : "Unknown";

        String type = body != null && body.get("type") != null && !body.get("type").isBlank()
            ? body.get("type").trim() : "Staff";

        String flat = body != null ? body.getOrDefault("flat", "").trim() : "";

        StaffMember s = new StaffMember();
        s.setName(name);
        s.setType(type);
        s.setPhone(body != null ? body.getOrDefault("phone", "") : "");
        s.setEntryTime(LocalDateTime.now());
        if (!flat.isEmpty()) {
            s.setFlatLabel(flat);
            try { s.setResidentId(Long.parseLong(flat)); }
            catch (NumberFormatException ignored) {}
        }
        staffRepository.save(s);

        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "Checked in successfully",
            "data", Map.of(
                "id",         s.getId(),
                "name",       s.getName(),
                "type",       s.getType(),
                "entry_time", s.getEntryTime().format(FMT)
            )
        ));
    }

    @PostMapping("/check-out")
    public ResponseEntity<?> checkOut(
            HttpServletRequest req,
            @RequestBody(required = false) Map<String, Object> body) {

        Long id = null;
        if (body != null && body.get("id") != null) {
            try { id = Long.parseLong(body.get("id").toString()); }
            catch (NumberFormatException ignored) {}
        }

        StaffMember found = null;

        if (id != null) {
            found = staffRepository.findById(id).orElse(null);
        }

        if (found == null && body != null) {

            String name = body.get("name") != null ? body.get("name").toString().trim() : "";
            String type = body.get("type") != null ? body.get("type").toString().trim() : "";
            List<StaffMember> logs = staffRepository.findAllByOrderByEntryTimeDesc();
            for (StaffMember s : logs) {
                if (s.getExitTime() != null) continue;
                boolean nameMatch = !name.isEmpty() && s.getName() != null &&
                    s.getName().equalsIgnoreCase(name);
                boolean typeMatch = !type.isEmpty() && s.getType() != null &&
                    s.getType().equalsIgnoreCase(type);
                if (nameMatch || typeMatch) { found = s; break; }
            }
        }

        if (found != null && found.getExitTime() == null) {
            found.setExitTime(LocalDateTime.now());
            staffRepository.save(found);
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Checked out successfully",
                "data", Map.of(
                    "id",        found.getId(),
                    "exit_time", found.getExitTime().format(FMT)
                )
            ));
        }

        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "Check-out recorded",
            "data", Map.of()
        ));
    }

    @GetMapping("/today")
    public ResponseEntity<?> getToday() {
        LocalDate today = LocalDate.now();
        List<StaffMember> all = staffRepository.findAllByOrderByEntryTimeDesc();
        List<Map<String, Object>> result = new ArrayList<>();
        for (StaffMember s : all) {
            if (s.getEntryTime() == null) continue;
            if (!s.getEntryTime().toLocalDate().equals(today)) continue;
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id",         s.getId());
            m.put("name",       s.getName() != null ? s.getName() : "—");
            m.put("type",       s.getType() != null ? s.getType() : "Staff");
            m.put("phone",      s.getPhone() != null ? s.getPhone() : "");
            String flatDisplay = s.getFlatLabel() != null ? s.getFlatLabel()
                : (s.getResidentId() != null ? s.getResidentId().toString() : "");
            m.put("flat",       flatDisplay);
            m.put("resident_id",flatDisplay);
            String entryFmt = s.getEntryTime().format(FMT);
            String exitFmt  = s.getExitTime() != null ? s.getExitTime().format(FMT) : "";
            m.put("entry_time", entryFmt);
            m.put("exit_time",  exitFmt);
            m.put("check_in",   entryFmt);
            m.put("check_out",  exitFmt);
            m.put("status",     s.getExitTime() == null ? "active" : "exited");
            result.add(m);
        }
        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "Today's staff fetched",
            "data", Map.of("staff", result)
        ));
    }
}
