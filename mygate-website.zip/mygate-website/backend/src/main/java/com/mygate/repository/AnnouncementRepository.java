package com.mygate.repository;

import com.mygate.entity.Announcement;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AnnouncementRepository extends JpaRepository<Announcement, Long> {
    List<Announcement> findAllByOrderByPinnedDescCreatedAtDesc();
    List<Announcement> findByCategoryOrderByCreatedAtDesc(String category);
}
