package com.mygate.service;

import com.mygate.dto.RegisterRequest;
import com.mygate.entity.Resident;
import com.mygate.entity.StaffMember;
import com.mygate.entity.UserAccount;
import com.mygate.repository.ResidentRepository;
import com.mygate.repository.StaffRepository;
import com.mygate.repository.UserAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class RegistrationService {

    private static final String ADMIN_INVITE_CODE = "MYGATE-ADMIN-2024";

    @Autowired private PasswordEncoder       passwordEncoder;
    @Autowired private UserAccountRepository userAccountRepo;
    @Autowired private ResidentRepository    residentRepo;
    @Autowired private StaffRepository       staffRepo;

    @Transactional
    public Map<String, Object> register(RegisterRequest req) {

        if (userAccountRepo.existsByEmail(req.getEmail())) {
            throw new IllegalArgumentException("An account with this email already exists.");
        }

        String role = req.getRole() != null ? req.getRole().toLowerCase() : "resident";
        if ("admin".equals(role)) {
            if (!ADMIN_INVITE_CODE.equals(req.getInviteCode())) {
                throw new IllegalArgumentException("Invalid admin invite code.");
            }
        }

        UserAccount account = new UserAccount();
        account.setReferenceId(generateRefId());
        account.setFirstName(req.getFirstName());
        account.setLastName(req.getLastName());
        account.setName(req.getName() != null ? req.getName()
                : req.getFirstName() + " " + req.getLastName());
        account.setEmail(req.getEmail());
        account.setPhone(req.getPhone());
        account.setRole(role.toUpperCase());
        account.setSocietyName(req.getSocietyName());
        account.setCity(req.getCity());

        account.setPasswordHash(passwordEncoder.encode(req.getPassword()));

        account.setCreatedAt(LocalDateTime.now());

        switch (role) {
            case "resident" -> {
                account.setFlatNumber(req.getFlatNumber());
                account.setBlock(req.getBlock());
                account.setFloor(req.getFloor());
                account.setOwnershipType(req.getOwnershipType());
                account.setStatus("PENDING");
            }
            case "guard" -> {
                account.setEmployeeId(req.getEmployeeId());
                account.setShift(req.getShift());
                account.setGate(req.getGate());
                account.setStatus("PENDING");
            }
            case "staff" -> {
                account.setStaffType(req.getStaffType());
                account.setAssignedFlat(req.getAssignedFlat());
                account.setStatus("PENDING");
            }
            case "maid" -> {
                account.setWorkType(req.getWorkType());
                account.setEmployerFlat(req.getEmployerFlat());
                account.setWorkHours(req.getWorkHours());
                account.setStatus("PENDING");
            }
            case "admin" -> account.setStatus("ACTIVE");
        }

        userAccountRepo.save(account);

        mirrorToRoleTable(role, req, account);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("referenceId", account.getReferenceId());
        result.put("status",      account.getStatus());
        result.put("message",     "ACTIVE".equals(account.getStatus())
                ? "Account created and activated."
                : "Registration submitted. Awaiting admin approval.");
        return result;
    }

    @Transactional
    public Map<String, Object> updateStatus(Long id, String newStatus, String approvedBy) {
        UserAccount account = userAccountRepo.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Account not found: " + id));

        String oldStatus = account.getStatus();
        account.setStatus(newStatus.toUpperCase());

        if ("APPROVED".equalsIgnoreCase(newStatus) || "ACTIVE".equalsIgnoreCase(newStatus)) {
            account.setApprovedAt(LocalDateTime.now());
            account.setApprovedBy(approvedBy);

        }

        userAccountRepo.save(account);

        Map<String, Object> res = new LinkedHashMap<>();
        res.put("id", id);
        res.put("oldStatus", oldStatus);
        res.put("newStatus", account.getStatus());
        return res;
    }

    public List<UserAccount> getPendingRegistrations() {
        return userAccountRepo.findByStatus("PENDING");
    }

    public List<UserAccount> getAllRegistrations() {
        return userAccountRepo.findAll();
    }

    public UserAccountRepository getUserAccountRepo() {
        return userAccountRepo;
    }

    private String generateRefId() {
        String chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        StringBuilder sb = new StringBuilder("MG-");
        Random rand = new Random();
        for (int i = 0; i < 6; i++) sb.append(chars.charAt(rand.nextInt(chars.length())));
        return sb.toString();
    }

    private void mirrorToRoleTable(String role, RegisterRequest req, UserAccount account) {
        try {
            switch (role) {
                case "resident" -> {

                    if (req.getFlatNumber() != null && !req.getFlatNumber().isBlank()) {
                        Resident r = new Resident();
                        r.setId(req.getFlatNumber());
                        r.setName(account.getName());
                        r.setPhone(req.getPhone());
                        r.setFlatNumber(req.getFlatNumber());
                        residentRepo.save(r);
                    }
                }
                case "staff", "maid" -> {
                    StaffMember s = new StaffMember();
                    s.setName(account.getName());
                    s.setType("maid".equals(role)
                            ? (req.getWorkType() != null ? req.getWorkType() : "maid")
                            : (req.getStaffType() != null ? req.getStaffType() : "staff"));
                    s.setPhone(req.getPhone());

                    staffRepo.save(s);
                }

                default -> {  }
            }
        } catch (Exception e) {
            System.err.println("[RegistrationService] Failed to mirror to role table: " + e.getMessage());
        }
    }
}
