package com.mygate.repository;

import com.mygate.entity.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserAccountRepository extends JpaRepository<UserAccount, Long> {

    Optional<UserAccount> findByEmail(String email);

    boolean existsByEmail(String email);

    List<UserAccount> findByStatus(String status);

    List<UserAccount> findByRole(String role);

    List<UserAccount> findByRoleAndStatus(String role, String status);

    Optional<UserAccount> findByReferenceId(String referenceId);
}
