package com.mygate.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "user_accounts")
public class UserAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "reference_id", unique = true, nullable = false)
    private String referenceId;

    @Column(nullable = false)
    private String firstName;

    @Column(nullable = false)
    private String lastName;

    @Column(nullable = false)
    private String name;

    @Column(unique = true, nullable = false)
    private String email;

    @Column(nullable = false)
    private String phone;

    @Column(nullable = false)
    private String passwordHash;

    @Column(nullable = false)
    private String role;

    @Column(nullable = false)
    private String status = "PENDING";

    private String societyName;
    private String city;

    private String flatNumber;
    private String block;
    private String floor;
    private String ownershipType;

    private String employeeId;
    private String shift;
    private String gate;

    private String staffType;
    private String assignedFlat;

    private String workType;
    private String employerFlat;
    private String workHours;

    @Column(updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    private LocalDateTime approvedAt;
    private String approvedBy;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getReferenceId() { return referenceId; }
    public void setReferenceId(String referenceId) { this.referenceId = referenceId; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String v) { this.firstName = v; }

    public String getLastName() { return lastName; }
    public void setLastName(String v) { this.lastName = v; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getSocietyName() { return societyName; }
    public void setSocietyName(String v) { this.societyName = v; }

    public String getCity() { return city; }
    public void setCity(String v) { this.city = v; }

    public String getFlatNumber() { return flatNumber; }
    public void setFlatNumber(String v) { this.flatNumber = v; }

    public String getBlock() { return block; }
    public void setBlock(String v) { this.block = v; }

    public String getFloor() { return floor; }
    public void setFloor(String v) { this.floor = v; }

    public String getOwnershipType() { return ownershipType; }
    public void setOwnershipType(String v) { this.ownershipType = v; }

    public String getEmployeeId() { return employeeId; }
    public void setEmployeeId(String v) { this.employeeId = v; }

    public String getShift() { return shift; }
    public void setShift(String v) { this.shift = v; }

    public String getGate() { return gate; }
    public void setGate(String v) { this.gate = v; }

    public String getStaffType() { return staffType; }
    public void setStaffType(String v) { this.staffType = v; }

    public String getAssignedFlat() { return assignedFlat; }
    public void setAssignedFlat(String v) { this.assignedFlat = v; }

    public String getWorkType() { return workType; }
    public void setWorkType(String v) { this.workType = v; }

    public String getEmployerFlat() { return employerFlat; }
    public void setEmployerFlat(String v) { this.employerFlat = v; }

    public String getWorkHours() { return workHours; }
    public void setWorkHours(String v) { this.workHours = v; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime v) { this.createdAt = v; }

    public LocalDateTime getApprovedAt() { return approvedAt; }
    public void setApprovedAt(LocalDateTime v) { this.approvedAt = v; }

    public String getApprovedBy() { return approvedBy; }
    public void setApprovedBy(String v) { this.approvedBy = v; }
}
