package com.mygate.controller;

import com.mygate.entity.Complaint;
import com.mygate.repository.ComplaintRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/complaints")
public class ComplaintController {

    @Autowired
    private ComplaintRepository complaintRepository;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

    @GetMapping
    public ResponseEntity<?> getAllComplaints(
            @RequestParam(required = false) String status) {

        List<Complaint> list = status != null
            ? complaintRepository.findByStatusOrderByCreatedAtDesc(status)
            : complaintRepository.findAllByOrderByCreatedAtDesc();

        return ResponseEntity.ok(Map.of(
            "success", true,
            "data", Map.of("complaints", list.stream().map(this::toMap).collect(Collectors.toList()))
        ));
    }

    @PostMapping
    public ResponseEntity<?> fileComplaint(
            HttpServletRequest req,
            @RequestBody Map<String, String> body) {

        String subject = body.get("subject");
        if (subject == null || subject.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "subject required"));
        }

        Complaint c = new Complaint();
        c.setSubject(subject);
        c.setDescription(body.getOrDefault("description", ""));
        c.setCategory(body.getOrDefault("category", "General"));
        c.setResidentFlat(body.getOrDefault("flat", body.getOrDefault("apartment", "")));
        c.setResidentName(body.getOrDefault("residentName", "Resident"));
        c.setStatus("open");

        complaintRepository.save(c);

        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "✅ Complaint filed",
            "data", toMap(c)
        ));
    }

    @PutMapping("/{id}/resolve")
    public ResponseEntity<?> resolveComplaint(@PathVariable Long id) {
        Optional<Complaint> opt = complaintRepository.findById(id);
        if (opt.isEmpty()) {
            return ResponseEntity.status(404).body(Map.of("success", false, "error", "Complaint not found"));
        }
        Complaint c = opt.get();
        c.setStatus("resolved");
        c.setResolvedAt(LocalDateTime.now());
        complaintRepository.save(c);

        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "✅ Complaint resolved",
            "data", toMap(c)
        ));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteComplaint(@PathVariable Long id) {
        complaintRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("success", true, "message", "Complaint deleted"));
    }

    private Map<String, Object> toMap(Complaint c) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id",           c.getId());
        m.put("subject",      c.getSubject());
        m.put("description",  c.getDescription() != null ? c.getDescription() : "");
        m.put("category",     c.getCategory() != null ? c.getCategory() : "General");
        m.put("status",       c.getStatus() != null ? c.getStatus() : "open");
        m.put("residentFlat", c.getResidentFlat() != null ? c.getResidentFlat() : "");
        m.put("residentName", c.getResidentName() != null ? c.getResidentName() : "Resident");
        m.put("createdAt",    c.getCreatedAt() != null ? c.getCreatedAt().format(FMT) : "");
        m.put("resolvedAt",   c.getResolvedAt() != null ? c.getResolvedAt().format(FMT) : "");
        return m;
    }
}
