package com.mygate.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity
@Table(name = "facility_bookings")
public class FacilityBooking {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false) private String facilityName;
    private String facilityType;
    private String residentName;
    private String residentFlat;
    private String residentPhone;
    private String purpose;
    private String bookingDate;
    private String timeSlot;
    private int expectedGuests = 0;
    private String status = "pending";
    private String adminNote;

    @Column(updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime reviewedAt;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getFacilityName() { return facilityName; }
    public void setFacilityName(String v) { this.facilityName = v; }
    public String getFacilityType() { return facilityType; }
    public void setFacilityType(String v) { this.facilityType = v; }
    public String getResidentName() { return residentName; }
    public void setResidentName(String v) { this.residentName = v; }
    public String getResidentFlat() { return residentFlat; }
    public void setResidentFlat(String v) { this.residentFlat = v; }
    public String getResidentPhone() { return residentPhone; }
    public void setResidentPhone(String v) { this.residentPhone = v; }
    public String getPurpose() { return purpose; }
    public void setPurpose(String v) { this.purpose = v; }
    public String getBookingDate() { return bookingDate; }
    public void setBookingDate(String v) { this.bookingDate = v; }
    public String getTimeSlot() { return timeSlot; }
    public void setTimeSlot(String v) { this.timeSlot = v; }
    public int getExpectedGuests() { return expectedGuests; }
    public void setExpectedGuests(int v) { this.expectedGuests = v; }
    public String getStatus() { return status; }
    public void setStatus(String v) { this.status = v; }
    public String getAdminNote() { return adminNote; }
    public void setAdminNote(String v) { this.adminNote = v; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime v) { this.createdAt = v; }
    public LocalDateTime getReviewedAt() { return reviewedAt; }
    public void setReviewedAt(LocalDateTime v) { this.reviewedAt = v; }
}
