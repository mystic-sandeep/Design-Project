package com.mygate.repository;

import com.mygate.entity.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findAllByOrderByCreatedAtDesc();
    List<Task> findByAssignToOrderByCreatedAtDesc(String assignTo);
    List<Task> findByStatusOrderByCreatedAtDesc(String status);
}
