package com.mygate.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "smart_devices")
public class SmartDevice {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String type;

    private String status = "offline";

    private String location;

    private String flatNumber;

    private String ipAddress;

    private String firmwareVersion = "v1.0.0";

    private String scheduleOnTime;

    private String scheduleOffTime;

    private String automationRule;

    private LocalDateTime lastSeen;
    private LocalDateTime lastActionAt;
    private String        lastActionBy;

    @Column(updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getFlatNumber() { return flatNumber; }
    public void setFlatNumber(String flatNumber) { this.flatNumber = flatNumber; }
    public String getIpAddress() { return ipAddress; }
    public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }
    public String getFirmwareVersion() { return firmwareVersion; }
    public void setFirmwareVersion(String firmwareVersion) { this.firmwareVersion = firmwareVersion; }
    public String getScheduleOnTime() { return scheduleOnTime; }
    public void setScheduleOnTime(String scheduleOnTime) { this.scheduleOnTime = scheduleOnTime; }
    public String getScheduleOffTime() { return scheduleOffTime; }
    public void setScheduleOffTime(String scheduleOffTime) { this.scheduleOffTime = scheduleOffTime; }
    public String getAutomationRule() { return automationRule; }
    public void setAutomationRule(String automationRule) { this.automationRule = automationRule; }
    public LocalDateTime getLastSeen() { return lastSeen; }
    public void setLastSeen(LocalDateTime lastSeen) { this.lastSeen = lastSeen; }
    public LocalDateTime getLastActionAt() { return lastActionAt; }
    public void setLastActionAt(LocalDateTime lastActionAt) { this.lastActionAt = lastActionAt; }
    public String getLastActionBy() { return lastActionBy; }
    public void setLastActionBy(String lastActionBy) { this.lastActionBy = lastActionBy; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
