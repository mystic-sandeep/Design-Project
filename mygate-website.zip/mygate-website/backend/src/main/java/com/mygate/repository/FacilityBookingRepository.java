package com.mygate.repository;

import com.mygate.entity.FacilityBooking;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FacilityBookingRepository extends JpaRepository<FacilityBooking, Long> {
    List<FacilityBooking> findAllByOrderByCreatedAtDesc();
    List<FacilityBooking> findByStatusOrderByCreatedAtDesc(String status);
    List<FacilityBooking> findByResidentFlatOrderByCreatedAtDesc(String flat);
}
