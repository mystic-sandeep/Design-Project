package com.mygate.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "complaints")
public class Complaint {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String subject;

    @Column(length = 2000)
    private String description;

    private String category;

    private String status = "open";

    @Column(name = "resident_flat")
    private String residentFlat;

    @Column(name = "resident_name")
    private String residentName;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "resolved_at")
    private LocalDateTime resolvedAt;

    @PrePersist
    protected void onCreate() {
        if (createdAt == null) createdAt = LocalDateTime.now();
        if (status == null) status = "open";
    }

    public Long getId()                          { return id; }
    public void setId(Long id)                   { this.id = id; }
    public String getSubject()                   { return subject; }
    public void setSubject(String s)             { this.subject = s; }
    public String getDescription()               { return description; }
    public void setDescription(String d)         { this.description = d; }
    public String getCategory()                  { return category; }
    public void setCategory(String c)            { this.category = c; }
    public String getStatus()                    { return status; }
    public void setStatus(String s)              { this.status = s; }
    public String getResidentFlat()              { return residentFlat; }
    public void setResidentFlat(String f)        { this.residentFlat = f; }
    public String getResidentName()              { return residentName; }
    public void setResidentName(String n)        { this.residentName = n; }
    public LocalDateTime getCreatedAt()          { return createdAt; }
    public void setCreatedAt(LocalDateTime t)    { this.createdAt = t; }
    public LocalDateTime getResolvedAt()         { return resolvedAt; }
    public void setResolvedAt(LocalDateTime t)   { this.resolvedAt = t; }
}
