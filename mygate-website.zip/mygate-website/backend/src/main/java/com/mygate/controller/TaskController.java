package com.mygate.controller;

import com.mygate.entity.Task;
import com.mygate.repository.TaskRepository;
import com.mygate.security.Permissions;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/tasks")
public class TaskController {

    @Autowired
    private TaskRepository taskRepository;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

    private static final Map<Long, String> otpStore = new java.util.concurrent.ConcurrentHashMap<>();

    @GetMapping
    public ResponseEntity<?> getAllTasks(
            HttpServletRequest req,
            @RequestParam(required = false) String assignTo) {

        List<Task> tasks = assignTo != null
                ? taskRepository.findByAssignToOrderByCreatedAtDesc(assignTo)
                : taskRepository.findAllByOrderByCreatedAtDesc();

        return ResponseEntity.ok(Map.of(
            "success", true,
            "data", Map.of("tasks", tasks.stream().map(this::toMap).collect(Collectors.toList()))
        ));
    }

    @GetMapping("/pending-otps")
    public ResponseEntity<?> getPendingOtps(@RequestParam(required = false) String recipient) {
        List<Task> all = taskRepository.findAllByOrderByCreatedAtDesc();
        List<Map<String, Object>> pending = all.stream()
            .filter(t -> "otp_pending".equals(t.getStatus()))
            .filter(t -> recipient == null || recipient.equals(t.getOtpRecipient()))
            .map(t -> {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("taskId",        t.getId());
                m.put("title",         t.getTitle());
                m.put("assignedName",  t.getAssignedName() != null ? t.getAssignedName() : "");
                m.put("otp",           t.getCompletionOtp());
                m.put("otpRecipient",  t.getOtpRecipient());
                m.put("generatedAt",   t.getOtpGeneratedAt() != null ? t.getOtpGeneratedAt().format(FMT) : "");
                return m;
            })
            .collect(Collectors.toList());

        return ResponseEntity.ok(Map.of("success", true, "data", Map.of("pendingOtps", pending)));
    }

    @PostMapping
    public ResponseEntity<?> createTask(
            HttpServletRequest req,
            @RequestBody Map<String, String> body) {

        String title = body.get("title");
        if (title == null || title.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "title required"));
        }

        Task task = new Task();
        task.setTitle(title);
        task.setDescription(body.getOrDefault("description", ""));
        task.setAssignTo(body.getOrDefault("assignTo", "maid"));
        task.setAssignedName(body.getOrDefault("assignedName", ""));
        task.setPriority(body.getOrDefault("priority", "medium"));
        task.setDueDate(body.getOrDefault("dueDate", ""));
        task.setLocation(body.getOrDefault("location", ""));
        task.setCreatedBy(body.getOrDefault("createdBy", "admin"));
        task.setOtpRecipient(body.getOrDefault("otpRecipient", "admin"));
        task.setStatus("pending");

        taskRepository.save(task);

        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "Task assigned",
            "data", toMap(task)
        ));
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateStatus(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {

        Optional<Task> opt = taskRepository.findById(id);
        if (opt.isEmpty()) {
            return ResponseEntity.status(404).body(Map.of("success", false, "error", "Task not found"));
        }

        Task task = opt.get();
        String newStatus = body.get("status");

        if (newStatus != null) {
            task.setStatus(newStatus);
            taskRepository.save(task);
        }

        return ResponseEntity.ok(Map.of("success", true, "message", "Status updated", "data", toMap(task)));
    }

    @PostMapping("/{id}/accept")
    public ResponseEntity<?> acceptTask(
            @PathVariable Long id,
            @RequestBody(required = false) Map<String, String> body) {

        Optional<Task> opt = taskRepository.findById(id);
        if (opt.isEmpty()) {
            return ResponseEntity.status(404).body(Map.of("success", false, "error", "Task not found"));
        }

        Task task = opt.get();
        if (!"pending".equals(task.getStatus())) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "Task already accepted or completed"));
        }

        task.setStatus("accepted");
        taskRepository.save(task);

        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "Task accepted. Begin work and mark done when complete.",
            "data", toMap(task)
        ));
    }

    @PostMapping("/{id}/request-otp")
    public ResponseEntity<?> requestOtp(
            @PathVariable Long id,
            @RequestBody(required = false) Map<String, String> body) {

        Optional<Task> opt = taskRepository.findById(id);
        if (opt.isEmpty()) {
            return ResponseEntity.status(404).body(Map.of("success", false, "error", "Task not found"));
        }

        Task task = opt.get();
        if ("done".equals(task.getStatus())) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "Task already completed"));
        }

        String otp = String.format("%06d", new Random().nextInt(999999));
        task.setCompletionOtp(otp);
        task.setOtpGeneratedAt(LocalDateTime.now());
        task.setOtpVerified(false);
        task.setStatus("otp_pending");

        if (body != null && body.containsKey("otpRecipient")) {
            task.setOtpRecipient(body.get("otpRecipient"));
        }

        taskRepository.save(task);
        otpStore.put(task.getId(), otp);

        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "OTP generated. Please ask the resident/admin to verify.",
            "data", Map.of(
                "taskId",       task.getId(),
                "otp",          otp,
                "otpRecipient", task.getOtpRecipient() != null ? task.getOtpRecipient() : "admin",
                "expiresIn",    "10 minutes"
            )
        ));
    }

    @PostMapping("/{id}/verify-otp")
    public ResponseEntity<?> verifyOtp(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {

        Optional<Task> opt = taskRepository.findById(id);
        if (opt.isEmpty()) {
            return ResponseEntity.status(404).body(Map.of("success", false, "error", "Task not found"));
        }

        Task task = opt.get();
        String submittedOtp = body.get("otp");

        if (submittedOtp == null || submittedOtp.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "OTP required"));
        }

        if (!"otp_pending".equals(task.getStatus())) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "No OTP pending for this task"));
        }

        if (task.getOtpGeneratedAt() != null) {
            LocalDateTime expiry = task.getOtpGeneratedAt().plusMinutes(10);
            if (LocalDateTime.now().isAfter(expiry)) {
                task.setStatus("accepted");
                task.setCompletionOtp(null);
                taskRepository.save(task);
                return ResponseEntity.badRequest().body(Map.of("success", false, "error", "OTP expired. Please request a new one."));
            }
        }

        if (!submittedOtp.equals(task.getCompletionOtp())) {
            return ResponseEntity.status(401).body(Map.of("success", false, "error", "Invalid OTP. Please try again."));
        }

        task.setStatus("done");
        task.setOtpVerified(true);
        task.setCompletedAt(LocalDateTime.now());
        taskRepository.save(task);
        otpStore.remove(task.getId());

        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "✅ OTP verified! Task marked as completed.",
            "data", toMap(task)
        ));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTask(@PathVariable Long id) {
        taskRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("success", true, "message", "Task deleted"));
    }

    private Map<String, Object> toMap(Task t) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id",            t.getId());
        m.put("title",         t.getTitle());
        m.put("description",   t.getDescription() != null ? t.getDescription() : "");
        m.put("assignTo",      t.getAssignTo() != null ? t.getAssignTo() : "");
        m.put("assignedName",  t.getAssignedName() != null ? t.getAssignedName() : "");
        m.put("priority",      t.getPriority() != null ? t.getPriority() : "medium");
        m.put("status",        t.getStatus() != null ? t.getStatus() : "pending");
        m.put("dueDate",       t.getDueDate() != null ? t.getDueDate() : "");
        m.put("location",      t.getLocation() != null ? t.getLocation() : "");
        m.put("createdBy",     t.getCreatedBy() != null ? t.getCreatedBy() : "");
        m.put("otpRecipient",  t.getOtpRecipient() != null ? t.getOtpRecipient() : "admin");
        m.put("otpVerified",   t.getOtpVerified() != null && t.getOtpVerified());
        m.put("hasOtp",        t.getCompletionOtp() != null && !t.getCompletionOtp().isEmpty());
        m.put("createdAt",     t.getCreatedAt() != null ? t.getCreatedAt().format(FMT) : "");
        m.put("completedAt",   t.getCompletedAt() != null ? t.getCompletedAt().format(FMT) : "");
        return m;
    }
}
