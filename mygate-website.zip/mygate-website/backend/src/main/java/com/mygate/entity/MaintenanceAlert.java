package com.mygate.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "maintenance_alerts")
public class MaintenanceAlert {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(length = 2000)
    private String description;

    private String area;

    private String severity = "low";

    @Column(name = "posted_by")
    private String postedBy = "Admin";

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        if (createdAt == null) createdAt = LocalDateTime.now();
    }

    public Long getId()                        { return id; }
    public void setId(Long id)                 { this.id = id; }
    public String getTitle()                   { return title; }
    public void setTitle(String t)             { this.title = t; }
    public String getDescription()             { return description; }
    public void setDescription(String d)       { this.description = d; }
    public String getArea()                    { return area; }
    public void setArea(String a)              { this.area = a; }
    public String getSeverity()                { return severity; }
    public void setSeverity(String s)          { this.severity = s; }
    public String getPostedBy()                { return postedBy; }
    public void setPostedBy(String p)          { this.postedBy = p; }
    public LocalDateTime getCreatedAt()        { return createdAt; }
    public void setCreatedAt(LocalDateTime c)  { this.createdAt = c; }
}
