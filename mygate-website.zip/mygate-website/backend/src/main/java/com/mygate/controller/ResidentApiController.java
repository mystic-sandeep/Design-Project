package com.mygate.controller;

import com.mygate.repository.StaffRepository;
import com.mygate.entity.Guest;
import com.mygate.entity.GuestStatus;
import com.mygate.repository.GuestRepository;
import com.mygate.security.Permissions;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/v2/resident")
public class ResidentApiController {

    @Autowired
    private StaffRepository staffMemberRepository;

    @Autowired
    private GuestRepository guestRepository;

    @Autowired
    private com.mygate.repository.VisitorRepository visitorRepository;

    @PostMapping("/approve-visitor")
    @Permissions("approveVisitor")
    public ResponseEntity<?> approveVisitor(
            HttpServletRequest req,
            @RequestBody Map<String, String> body) {

        String passCode = body.get("passCode");
        if (passCode == null || passCode.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false, "error", "passCode required"
            ));
        }

        Optional<Guest> guestOpt = guestRepository.findByPassCode(passCode);
        if (guestOpt.isEmpty()) {
            return ResponseEntity.status(404).body(Map.of(
                "success", false, "error", "Invalid or expired passcode"
            ));
        }

        Guest guest = guestOpt.get();
        if (guest.getStatus() == GuestStatus.CHECKED_IN) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false, "error", "Visitor already approved"
            ));
        }

        guest.setStatus(GuestStatus.APPROVED);
        guest.setApprovedAt(LocalDateTime.now());
        guestRepository.save(guest);

        List<com.mygate.entity.Visitor> visitors = visitorRepository.findAllByOrderByIdDesc();
        for (com.mygate.entity.Visitor v : visitors) {
            if ("pending".equalsIgnoreCase(v.getStatus()) && v.getName().equalsIgnoreCase(guest.getName())) {
                v.setStatus("approved");
                visitorRepository.save(v);
                break;
            }
        }

        GuardApiController.pushApprovalNotification(Map.of(
            "visitorName", guest.getName(),
            "apartmentNumber", guest.getResidentId()
        ));

        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "✅ Visitor approved",
            "data", Map.of(
                "visitorName",     guest.getName(),
                "apartmentNumber", guest.getResidentId(),
                "status",          "Approved"
            )
        ));
    }

    @GetMapping("/bills")
    @Permissions("viewBills")
    public ResponseEntity<?> viewBills(HttpServletRequest req) {
        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "✅ Bills retrieved",
            "data", Map.of("pendingAmount", 5000, "currency", "INR", "dueDate", "2025-06-01")
        ));
    }

    @PostMapping("/manage-vehicles")
    @Permissions("manageVehicles")
    public ResponseEntity<?> manageVehicles(HttpServletRequest req) {
        return ResponseEntity.ok(Map.of(
            "success", true, "message", "✅ Vehicle managed", "data", Map.of("status", "Logged")
        ));
    }

    @PostMapping("/file-complaint")
    @Permissions("fileComplaint")
    public ResponseEntity<?> fileComplaint(
            HttpServletRequest req,
            @RequestBody Map<String, String> body) {

        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "✅ Complaint filed",
            "data", Map.of(
                "status",      "Open",
                "subject",     body.getOrDefault("subject", "General"),
                "description", body.getOrDefault("description", ""),
                "filedAt",     LocalDateTime.now().toString()
            )
        ));
    }

    @PostMapping("/hire-maid")
    @Permissions("hireMaid")
    public ResponseEntity<?> hireMaid(
            HttpServletRequest req,
            @RequestBody(required = false) Map<String, String> body) {
        if (body == null) body = new java.util.HashMap<>();
        com.mygate.entity.StaffMember s = new com.mygate.entity.StaffMember();
        s.setName(body.getOrDefault("name", "Maid"));
        s.setType(body.getOrDefault("type", "maid"));
        s.setPhone(body.getOrDefault("phone", ""));

        String scheduledAt = body.get("scheduledAt");
        if (scheduledAt != null && !scheduledAt.isBlank()) {
            try {
                s.setEntryTime(java.time.LocalDateTime.parse(scheduledAt));
            } catch (Exception ignored) {
                s.setEntryTime(java.time.LocalDateTime.now());
            }
        } else {
            s.setEntryTime(java.time.LocalDateTime.now());
        }
        String flat = body.getOrDefault("flat", body.getOrDefault("apartment", ""));
        if (!flat.isBlank()) {
            s.setFlatLabel(flat);
            try { s.setResidentId(Long.parseLong(flat)); } catch (NumberFormatException ignored) {}
        }
        staffMemberRepository.save(s);
        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "✅ Maid booking confirmed",
            "data", Map.of(
                "id",          s.getId(),
                "name",        s.getName(),
                "type",        s.getType(),
                "flat",        flat,
                "scheduledAt", s.getEntryTime().toString(),
                "status",      "Booked"
            )
        ));
    }
}
