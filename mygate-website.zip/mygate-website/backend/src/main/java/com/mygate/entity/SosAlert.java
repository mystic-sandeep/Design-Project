package com.mygate.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "sos_alerts")
public class SosAlert {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "resident_name")
    private String residentName;

    @Column(name = "flat_number")
    private String flatNumber;

    private String message;

    private String status = "active";

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        if (createdAt == null) createdAt = LocalDateTime.now();
        if (status == null) status = "active";
    }

    public Long getId()                        { return id; }
    public void setId(Long id)                 { this.id = id; }
    public String getResidentName()            { return residentName; }
    public void setResidentName(String n)      { this.residentName = n; }
    public String getFlatNumber()              { return flatNumber; }
    public void setFlatNumber(String f)        { this.flatNumber = f; }
    public String getMessage()                 { return message; }
    public void setMessage(String m)           { this.message = m; }
    public String getStatus()                  { return status; }
    public void setStatus(String s)            { this.status = s; }
    public LocalDateTime getCreatedAt()        { return createdAt; }
    public void setCreatedAt(LocalDateTime c)  { this.createdAt = c; }
}
