package com.mygate.controller;

import com.mygate.entity.SosAlert;
import com.mygate.repository.SosAlertRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/sos")
public class SosController {

    @Autowired
    private SosAlertRepository sosAlertRepository;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

    @PostMapping
    public ResponseEntity<?> sendSos(
            HttpServletRequest req,
            @RequestBody Map<String, String> body) {

        String resident = body.getOrDefault("resident", "Resident");
        String flat     = body.getOrDefault("flat", "—");
        String message  = body.getOrDefault("message", "Emergency! Please send help.");

        SosAlert alert = new SosAlert();
        alert.setResidentName(resident);
        alert.setFlatNumber(flat);
        alert.setMessage(message);
        alert.setStatus("active");
        sosAlertRepository.save(alert);

        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "🆘 SOS Alert sent to Admin and Guards",
            "data", toMap(alert)
        ));
    }

    @GetMapping
    public ResponseEntity<?> getAllSos() {
        List<SosAlert> alerts = sosAlertRepository.findAllByOrderByCreatedAtDesc();
        return ResponseEntity.ok(Map.of(
            "success", true,
            "data", Map.of("alerts", alerts.stream().map(this::toMap).collect(Collectors.toList()))
        ));
    }

    @PutMapping("/{id}/resolve")
    public ResponseEntity<?> resolveSos(@PathVariable Long id) {
        Optional<SosAlert> opt = sosAlertRepository.findById(id);
        if (opt.isEmpty()) {
            return ResponseEntity.status(404).body(Map.of("success", false, "error", "Alert not found"));
        }
        SosAlert alert = opt.get();
        alert.setStatus("resolved");
        sosAlertRepository.save(alert);
        return ResponseEntity.ok(Map.of("success", true, "message", "SOS resolved", "data", toMap(alert)));
    }

    private Map<String, Object> toMap(SosAlert a) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id",       a.getId());
        m.put("resident", a.getResidentName() != null ? a.getResidentName() : "");
        m.put("flat",     a.getFlatNumber() != null ? a.getFlatNumber() : "");
        m.put("message",  a.getMessage() != null ? a.getMessage() : "");
        m.put("status",   a.getStatus() != null ? a.getStatus() : "active");
        m.put("createdAt",a.getCreatedAt() != null ? a.getCreatedAt().format(FMT) : "");
        return m;
    }
}
