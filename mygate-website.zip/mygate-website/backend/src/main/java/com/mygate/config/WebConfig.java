package com.mygate.config;

import com.mygate.security.RbacInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Autowired
    private RbacInterceptor rbacInterceptor;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("*")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(false);
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(rbacInterceptor)
                .addPathPatterns("/api/**")
                .excludePathPatterns(
                        "/api/auth/**",
                        "/api/stats",
                        "/api/v2/sos",
                        "/api/v2/maintenance",
                        "/api/v2/tasks",
                        "/api/v2/tasks/**",
                        "/api/v2/staff/check-in",
                        "/api/v2/staff/check-out",
                        "/api/v2/staff/today",
                        "/api/v2/facilities",
                        "/api/v2/facilities/**",
                        "/api/v2/announcements",
                        "/api/v2/announcements/**",
                        "/api/v2/complaints",
                        "/api/v2/complaints/**",
                        "/api/v2/maintenance/**",
                        "/api/v2/resident/**"
                );
    }
}
