package com.mygate.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "tasks")
public class Task {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(length = 1000)
    private String description;

    @Column(name = "assign_to")
    private String assignTo;

    @Column(name = "assigned_name")
    private String assignedName;

    private String priority = "medium";

    private String status = "pending";

    @Column(name = "due_date")
    private String dueDate;

    private String location;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "completion_otp")
    private String completionOtp;

    @Column(name = "otp_generated_at")
    private LocalDateTime otpGeneratedAt;

    @Column(name = "otp_verified")
    private Boolean otpVerified = false;

    @Column(name = "otp_recipient")
    private String otpRecipient;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        if (createdAt == null) createdAt = LocalDateTime.now();
        if (status == null)    status    = "pending";
        if (otpVerified == null) otpVerified = false;
    }

    public Long getId()                         { return id; }
    public void setId(Long id)                  { this.id = id; }
    public String getTitle()                    { return title; }
    public void setTitle(String t)              { this.title = t; }
    public String getDescription()              { return description; }
    public void setDescription(String d)        { this.description = d; }
    public String getAssignTo()                 { return assignTo; }
    public void setAssignTo(String a)           { this.assignTo = a; }
    public String getAssignedName()             { return assignedName; }
    public void setAssignedName(String a)       { this.assignedName = a; }
    public String getPriority()                 { return priority; }
    public void setPriority(String p)           { this.priority = p; }
    public String getStatus()                   { return status; }
    public void setStatus(String s)             { this.status = s; }
    public String getDueDate()                  { return dueDate; }
    public void setDueDate(String d)            { this.dueDate = d; }
    public String getLocation()                 { return location; }
    public void setLocation(String l)           { this.location = l; }
    public String getCreatedBy()                { return createdBy; }
    public void setCreatedBy(String c)          { this.createdBy = c; }
    public String getCompletionOtp()            { return completionOtp; }
    public void setCompletionOtp(String o)      { this.completionOtp = o; }
    public LocalDateTime getOtpGeneratedAt()    { return otpGeneratedAt; }
    public void setOtpGeneratedAt(LocalDateTime t){ this.otpGeneratedAt = t; }
    public Boolean getOtpVerified()             { return otpVerified; }
    public void setOtpVerified(Boolean v)       { this.otpVerified = v; }
    public String getOtpRecipient()             { return otpRecipient; }
    public void setOtpRecipient(String r)       { this.otpRecipient = r; }
    public LocalDateTime getCompletedAt()       { return completedAt; }
    public void setCompletedAt(LocalDateTime t) { this.completedAt = t; }
    public LocalDateTime getCreatedAt()         { return createdAt; }
    public void setCreatedAt(LocalDateTime c)   { this.createdAt = c; }
}
