package com.mygate.controller;

import com.mygate.dto.LoginRequest;
import com.mygate.dto.RegisterRequest;
import com.mygate.enums.Role;
import com.mygate.security.JwtUtil;
import com.mygate.service.RegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired private PasswordEncoder      passwordEncoder;
    @Autowired private JwtUtil              jwtUtil;
    @Autowired private RegistrationService  registrationService;

    private static final Map<String, String[]> USERS = new HashMap<>();
    static {
        USERS.put("admin@mygate.com",    new String[]{"admin123",    "Admin User",     "A-001"});
        USERS.put("guard@mygate.com",    new String[]{"guard123",    "Security Guard", "G-001"});
        USERS.put("resident@mygate.com", new String[]{"resident123", "John Resident",  "B-202"});
        USERS.put("staff@mygate.com",    new String[]{"staff123",    "Staff Member",   "S-001"});
        USERS.put("maid@mygate.com",     new String[]{"maid123",     "Maid Worker",    null  });
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody LoginRequest request, HttpServletResponse response) {

        String email    = request.getEmail();
        String password = request.getPassword();
        String roleStr  = request.getRole() != null ? request.getRole().toLowerCase() : "resident";

        if (email == null || email.isEmpty() || password == null || password.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false, "error", "Email and password required"
            ));
        }

        Role role;
        try { role = Role.fromString(roleStr); }
        catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false, "error", "Invalid role"
            ));
        }

        String[] userData = USERS.get(email);
        if (userData != null && userData[0].equals(password)) {
            String expectedRole = email.split("@")[0];
            if (!roleStr.equals(expectedRole) && !email.equals("admin@mygate.com")) {
                return ResponseEntity.status(403).body(Map.of(
                    "success", false, "error", "This account is not a " + roleStr
                ));
            }
            return buildTokenResponse(email, userData[1], userData[2], roleStr, role, response);
        }

        try {
            var accountOpt = registrationService.getUserAccountRepo().findByEmail(email);
            if (accountOpt.isPresent()) {
                var account = accountOpt.get();

                if (!passwordEncoder.matches(password, account.getPasswordHash())) {
                    return ResponseEntity.status(401).body(Map.of(
                        "success", false, "error", "Invalid credentials"
                    ));
                }

                if (!account.getRole().equalsIgnoreCase(roleStr)) {
                    return ResponseEntity.status(403).body(Map.of(
                        "success", false, "error", "This account is registered as " + account.getRole()
                    ));
                }

                if ("PENDING".equals(account.getStatus())) {
                    return ResponseEntity.status(403).body(Map.of(
                        "success", false, "error",
                        "Your account is pending admin approval. Reference: " + account.getReferenceId()
                    ));
                }
                if ("REJECTED".equals(account.getStatus())) {
                    return ResponseEntity.status(403).body(Map.of(
                        "success", false, "error", "Your registration was rejected. Contact the admin."
                    ));
                }

                String apartment = account.getFlatNumber() != null ? account.getFlatNumber()
                        : account.getAssignedFlat() != null ? account.getAssignedFlat() : "";
                return buildTokenResponse(email, account.getName(), apartment, roleStr, role, response);
            }
        } catch (Exception ignored) {  }

        return ResponseEntity.status(401).body(Map.of(
            "success", false, "error", "Invalid credentials"
        ));
    }

    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody RegisterRequest request) {

        if (request.getEmail() == null || request.getEmail().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "Email is required"));
        }
        if (request.getPassword() == null || request.getPassword().length() < 8) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "Password must be at least 8 characters"));
        }
        if (request.getFirstName() == null || request.getFirstName().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "First name is required"));
        }

        try {
            Map<String, Object> result = registrationService.register(request);

            Map<String, Object> response = new HashMap<>();
            response.put("success",     true);
            response.put("message",     result.get("message"));
            response.put("referenceId", result.get("referenceId"));
            response.put("data",        result);
            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false, "error", e.getMessage()
            ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of(
                "success", false, "error", "Registration failed: " + e.getMessage()
            ));
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletResponse response) {
        Cookie cookie = new Cookie("mg_token", null);
        cookie.setMaxAge(0);
        cookie.setPath("/");
        response.addCookie(cookie);
        return ResponseEntity.ok(Map.of("success", true));
    }

    @PostMapping("/verify")
    public ResponseEntity<Map<String, Object>> verify(
            @RequestHeader(value = "Authorization", required = false) String authHeader) {

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(401).body(Map.of("success", false, "error", "Token missing"));
        }

        String token = authHeader.substring(7);
        if (!jwtUtil.validateToken(token)) {
            return ResponseEntity.status(401).body(Map.of("success", false, "error", "Invalid or expired token"));
        }

        String roleStr = jwtUtil.getRoleFromToken(token);
        String email   = jwtUtil.getEmailFromToken(token);
        Role   role    = Role.fromString(roleStr);

        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "Token valid",
            "user", Map.of(
                "id",          email,
                "email",       email,
                "role",        roleStr,
                "roleDisplay", role.getDisplayName(),
                "permissions", role.getPermissions()
            )
        ));
    }

    private ResponseEntity<Map<String, Object>> buildTokenResponse(
            String email, String name, String apartment, String roleStr, Role role, HttpServletResponse response) {

        String token = jwtUtil.generateToken(email, email, roleStr);

        Cookie jwtCookie = new Cookie("mg_token", token);
        jwtCookie.setHttpOnly(true);
        jwtCookie.setSecure(false);
        jwtCookie.setPath("/");
        jwtCookie.setMaxAge(24 * 60 * 60);
        response.addCookie(jwtCookie);

        Map<String, Object> respBody = new HashMap<>();
        respBody.put("success", true);
        respBody.put("message", "Login successful");
        respBody.put("token", token);
        respBody.put("user", Map.of(
            "id",          email,
            "email",       email,
            "name",        name,
            "apartment",   apartment != null ? apartment : "",
            "role",        roleStr,
            "roleDisplay", role.getDisplayName(),
            "permissions", role.getPermissions()
        ));
        return ResponseEntity.ok(respBody);
    }
}
