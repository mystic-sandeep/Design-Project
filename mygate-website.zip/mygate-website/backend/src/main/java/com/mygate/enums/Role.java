package com.mygate.enums;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public enum Role {
    RESIDENT("Resident",    new String[]{"approveVisitor","viewBills","manageVehicles","fileComplaint","hireMaid","sendSOS","assignTask"}),
    GUARD(   "Guard",       new String[]{"registerVisitor","markEntry","markExit","logVehicle","checkIn","checkOut","patrolPoint","viewTasks"}),
    ADMIN(   "Admin",       new String[]{"*"}),
    STAFF(   "Staff",       new String[]{"checkIn","checkOut","viewTasks","updateTaskStatus"}),
    MAID(    "Maid",        new String[]{"checkIn","checkOut","viewAssignments","updateTaskStatus"});

    private final String displayName;
    private final Set<String> permissions;

    Role(String displayName, String[] permissions) {
        this.displayName = displayName;
        this.permissions = new HashSet<>(Arrays.asList(permissions));
    }

    public String getDisplayName() { return displayName; }
    public Set<String> getPermissions() { return permissions; }

    public boolean hasPermission(String permission) {
        if (permissions.contains("*")) return true;
        return permissions.contains(permission);
    }

    public static Role fromString(String roleStr) {
        if (roleStr == null) return RESIDENT;
        try { return Role.valueOf(roleStr.toUpperCase()); }
        catch (IllegalArgumentException e) { return RESIDENT; }
    }
}
