package com.mygate.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "announcements")
public class Announcement {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false) private String title;
    @Column(length = 2000) private String message;
    private String category;
    private String postedBy;
    private String emoji;
    private boolean pinned = false;

    @Column(updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String v) { this.title = v; }
    public String getMessage() { return message; }
    public void setMessage(String v) { this.message = v; }
    public String getCategory() { return category; }
    public void setCategory(String v) { this.category = v; }
    public String getPostedBy() { return postedBy; }
    public void setPostedBy(String v) { this.postedBy = v; }
    public String getEmoji() { return emoji; }
    public void setEmoji(String v) { this.emoji = v; }
    public boolean isPinned() { return pinned; }
    public void setPinned(boolean v) { this.pinned = v; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime v) { this.createdAt = v; }
}
