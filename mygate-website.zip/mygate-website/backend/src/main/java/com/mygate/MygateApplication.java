package com.mygate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MygateApplication {
    public static void main(String[] args) {
        SpringApplication.run(MygateApplication.class, args);
    }
}
