package com.mygate.controller;

import com.mygate.entity.UserAccount;
import com.mygate.security.Permissions;
import com.mygate.service.RegistrationService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/admin/registrations")
public class RegistrationAdminController {

    @Autowired private RegistrationService registrationService;

    @GetMapping
    @Permissions("manageUsers")
    public ResponseEntity<?> getAllRegistrations(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String role,
            HttpServletRequest req) {

        List<UserAccount> list = registrationService.getAllRegistrations();

        if (status != null && !status.isBlank()) {
            list = list.stream()
                    .filter(u -> u.getStatus().equalsIgnoreCase(status))
                    .collect(Collectors.toList());
        }
        if (role != null && !role.isBlank()) {
            list = list.stream()
                    .filter(u -> u.getRole().equalsIgnoreCase(role))
                    .collect(Collectors.toList());
        }

        return ok(req, "Registrations fetched",
                Map.of("registrations", list.stream().map(this::toMap).collect(Collectors.toList()),
                       "total", list.size()));
    }

    @GetMapping("/pending")
    @Permissions("manageUsers")
    public ResponseEntity<?> getPending(HttpServletRequest req) {
        List<UserAccount> list = registrationService.getPendingRegistrations();
        return ok(req, "Pending registrations fetched",
                Map.of("registrations", list.stream().map(this::toMap).collect(Collectors.toList()),
                       "total", list.size()));
    }

    @PutMapping("/{id}/status")
    @Permissions("manageUsers")
    public ResponseEntity<?> updateStatus(
            @PathVariable Long id,
            @RequestBody Map<String, String> body,
            HttpServletRequest req) {

        String newStatus = body.get("status");
        if (newStatus == null || newStatus.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false, "error", "status field required (APPROVED | REJECTED | ACTIVE)"
            ));
        }

        String approvedBy = req.getAttribute("userEmail") != null
                ? req.getAttribute("userEmail").toString() : "admin";

        Map<String, Object> result = registrationService.updateStatus(id, newStatus, approvedBy);
        return ok(req, "Status updated", result);
    }

    private Map<String, Object> toMap(UserAccount u) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id",          u.getId());
        m.put("referenceId", u.getReferenceId());
        m.put("name",        u.getName());
        m.put("email",       u.getEmail());
        m.put("phone",       u.getPhone());
        m.put("role",        u.getRole());
        m.put("status",      u.getStatus());
        m.put("societyName", u.getSocietyName());
        m.put("city",        u.getCity());
        m.put("createdAt",   u.getCreatedAt() != null ? u.getCreatedAt().toString() : "");
        m.put("approvedAt",  u.getApprovedAt() != null ? u.getApprovedAt().toString() : "");
        m.put("approvedBy",  u.getApprovedBy());

        if (u.getFlatNumber()   != null) m.put("flatNumber",   u.getFlatNumber());
        if (u.getBlock()        != null) m.put("block",        u.getBlock());
        if (u.getOwnershipType()!= null) m.put("ownershipType",u.getOwnershipType());
        if (u.getShift()        != null) m.put("shift",        u.getShift());
        if (u.getGate()         != null) m.put("gate",         u.getGate());
        if (u.getStaffType()    != null) m.put("staffType",    u.getStaffType());
        if (u.getWorkType()     != null) m.put("workType",     u.getWorkType());
        if (u.getEmployerFlat() != null) m.put("employerFlat", u.getEmployerFlat());
        return m;
    }

    private ResponseEntity<?> ok(HttpServletRequest req, String msg, Map<String, Object> data) {
        com.mygate.enums.Role role = (com.mygate.enums.Role) req.getAttribute("userRole");
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("success",   true);
        resp.put("message",   msg);
        resp.put("data",      data);
        resp.put("executedBy", Map.of(
            "userId", req.getAttribute("userId")    != null ? req.getAttribute("userId")    : "admin",
            "email",  req.getAttribute("userEmail") != null ? req.getAttribute("userEmail") : "",
            "role",   role != null ? role.getDisplayName() : "Admin"
        ));
        resp.put("timestamp", System.currentTimeMillis());
        return ResponseEntity.ok(resp);
    }
}
