package com.mygate.controller;

import com.mygate.entity.MaintenanceAlert;
import com.mygate.repository.MaintenanceAlertRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/maintenance")
public class MaintenanceController {

    @Autowired
    private MaintenanceAlertRepository maintenanceRepo;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

    @GetMapping
    public ResponseEntity<?> getAll() {
        List<MaintenanceAlert> alerts = maintenanceRepo.findAllByOrderByCreatedAtDesc();
        return ResponseEntity.ok(Map.of(
            "success", true,
            "data", Map.of("alerts", alerts.stream().map(this::toMap).collect(Collectors.toList()))
        ));
    }

    @PostMapping
    public ResponseEntity<?> createAlert(@RequestBody Map<String, String> body) {
        String title = body.get("title");
        if (title == null || title.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "title required"));
        }

        MaintenanceAlert alert = new MaintenanceAlert();
        alert.setTitle(title);
        alert.setDescription(body.getOrDefault("description", ""));
        alert.setArea(body.getOrDefault("area", ""));
        alert.setSeverity(body.getOrDefault("severity", "low"));
        alert.setPostedBy(body.getOrDefault("postedBy", "Admin"));
        maintenanceRepo.save(alert);

        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "Maintenance alert posted",
            "data", toMap(alert)
        ));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteAlert(@PathVariable Long id) {
        maintenanceRepo.deleteById(id);
        return ResponseEntity.ok(Map.of("success", true, "message", "Alert deleted"));
    }

    private Map<String, Object> toMap(MaintenanceAlert a) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id",          a.getId());
        m.put("title",       a.getTitle());
        m.put("description", a.getDescription() != null ? a.getDescription() : "");
        m.put("area",        a.getArea() != null ? a.getArea() : "");
        m.put("severity",    a.getSeverity() != null ? a.getSeverity() : "low");
        m.put("postedBy",    a.getPostedBy() != null ? a.getPostedBy() : "Admin");
        m.put("createdAt",   a.getCreatedAt() != null ? a.getCreatedAt().format(FMT) : "");
        return m;
    }
}
