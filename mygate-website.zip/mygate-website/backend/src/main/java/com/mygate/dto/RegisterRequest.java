package com.mygate.dto;

public class RegisterRequest {
    private String firstName;
    private String lastName;
    private String name;
    private String email;
    private String phone;
    private String password;
    private String role;
    private String societyName;
    private String city;

    private String flatNumber;
    private String block;
    private String floor;
    private String ownershipType;

    private String employeeId;
    private String shift;
    private String gate;

    private String staffType;
    private String assignedFlat;

    private String workType;
    private String employerFlat;
    private String workHours;

    private String inviteCode;

    public String getFirstName()     { return firstName; }
    public void setFirstName(String v){ this.firstName = v; }
    public String getLastName()      { return lastName; }
    public void setLastName(String v) { this.lastName = v; }
    public String getName()          { return name; }
    public void setName(String v)    { this.name = v; }
    public String getEmail()         { return email; }
    public void setEmail(String v)   { this.email = v; }
    public String getPhone()         { return phone; }
    public void setPhone(String v)   { this.phone = v; }
    public String getPassword()      { return password; }
    public void setPassword(String v){ this.password = v; }
    public String getRole()          { return role; }
    public void setRole(String v)    { this.role = v; }
    public String getSocietyName()   { return societyName; }
    public void setSocietyName(String v){ this.societyName = v; }
    public String getCity()          { return city; }
    public void setCity(String v)    { this.city = v; }
    public String getFlatNumber()    { return flatNumber; }
    public void setFlatNumber(String v){ this.flatNumber = v; }
    public String getBlock()         { return block; }
    public void setBlock(String v)   { this.block = v; }
    public String getFloor()         { return floor; }
    public void setFloor(String v)   { this.floor = v; }
    public String getOwnershipType() { return ownershipType; }
    public void setOwnershipType(String v){ this.ownershipType = v; }
    public String getEmployeeId()    { return employeeId; }
    public void setEmployeeId(String v){ this.employeeId = v; }
    public String getShift()         { return shift; }
    public void setShift(String v)   { this.shift = v; }
    public String getGate()          { return gate; }
    public void setGate(String v)    { this.gate = v; }
    public String getStaffType()     { return staffType; }
    public void setStaffType(String v){ this.staffType = v; }
    public String getAssignedFlat()  { return assignedFlat; }
    public void setAssignedFlat(String v){ this.assignedFlat = v; }
    public String getWorkType()      { return workType; }
    public void setWorkType(String v){ this.workType = v; }
    public String getEmployerFlat()  { return employerFlat; }
    public void setEmployerFlat(String v){ this.employerFlat = v; }
    public String getWorkHours()     { return workHours; }
    public void setWorkHours(String v){ this.workHours = v; }
    public String getInviteCode()    { return inviteCode; }
    public void setInviteCode(String v){ this.inviteCode = v; }
}
