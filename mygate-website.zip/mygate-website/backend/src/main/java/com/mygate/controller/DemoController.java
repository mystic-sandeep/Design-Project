package com.mygate.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/demo")
public class DemoController {

    @PostMapping
    public ResponseEntity<Map<String, Object>> submitDemo(@RequestBody Map<String, String> body) {
        String name = body.getOrDefault("name", "");
        if (name.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "Name is required"));
        }

        String refId = "DEMO-" + System.currentTimeMillis() % 100000;

        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "Thank you, " + name + "! Our team will reach out within 24 hours to schedule your free demo.",
            "referenceId", refId
        ));
    }
}
