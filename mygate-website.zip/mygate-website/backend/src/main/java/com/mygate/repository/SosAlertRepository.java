package com.mygate.repository;

import com.mygate.entity.SosAlert;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SosAlertRepository extends JpaRepository<SosAlert, Long> {
    List<SosAlert> findAllByOrderByCreatedAtDesc();
    List<SosAlert> findByStatusOrderByCreatedAtDesc(String status);
}
