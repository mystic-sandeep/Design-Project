const API = '';

function getUser()  { try { return JSON.parse(localStorage.getItem('mg_user')||'{}'); } catch(e){ return {}; } }
function getToken() { try { return JSON.parse(localStorage.getItem('mg_user')||'{}')?.token || ''; } catch(e){ return ''; } }

async function apiFetch(path, opts={}) {
  const headers = { 'Content-Type':'application/json', 'Authorization':'Bearer '+getToken(), ...(opts.headers||{}) };
  try {
    const r = await fetch(API+path, {...opts, headers});
    if (!r.ok && r.status === 401) { logout(); return null; }
    return await r.json();
  } catch(e) {
    return null;
  }
}

async function logout() {
  await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
  localStorage.removeItem('mg_user');
  window.location.href = '/index.html';
}

function showPage(id) {
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
  const pg  = document.getElementById('page-'+id);
  const nav = document.querySelector(`.nav-item[data-page="${id}"]`);
  if(pg)  pg.classList.add('active');
  if(nav) nav.classList.add('active');
  const title = document.getElementById('pageTitle');
  if(title && nav) title.textContent = nav.textContent.trim();
}

function openModal(id)  { document.getElementById(id)?.classList.add('open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }

function fmtDateTime(dt) {
  if(!dt) return '—';
  try {
    const d = new Date(dt);
    if(isNaN(d)) return dt; 
    return d.toLocaleDateString('en-IN',{day:'2-digit',month:'short'})+' '+
           d.toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'});
  } catch(e){ return dt||'—'; }
}
function fmtTime(dt) {
  if(!dt) return '—';
  try { return new Date(dt).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'}); }
  catch(e){ return '—'; }
}

function toast(msg, type='success') {
  const existing = document.querySelector('.mg-toast');
  if(existing) existing.remove();
  const t = document.createElement('div');
  t.className = 'mg-toast';
  t.style.cssText = `position:fixed;bottom:1.5rem;right:1.5rem;z-index:9999;
    background:${type==='success'?'#16a34a':type==='error'?'#dc2626':'#f59e0b'};
    color:#fff;padding:.75rem 1.25rem;border-radius:10px;font-size:.85rem;font-weight:600;
    box-shadow:0 4px 20px rgba(0,0,0,.25);transition:opacity .4s;font-family:'Inter',sans-serif;
    max-width:320px;`;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(()=>{ t.style.opacity='0'; setTimeout(()=>t.remove(),400); }, 3000);
}

const GPS_STORAGE_KEY = 'mg_building_gps';

function getBuildingGPS() {
  try { return JSON.parse(localStorage.getItem(GPS_STORAGE_KEY) || 'null'); }
  catch(e) { return null; }
}

function saveBuildingGPS(cfg) {
  localStorage.setItem(GPS_STORAGE_KEY, JSON.stringify(cfg));
}

function haversineMetres(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 +
            Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

async function checkInsideBuilding() {
  const cfg = getBuildingGPS();
  if (!cfg || !cfg.lat || !cfg.lng) {
    return { allowed: true, distance: null, reason: 'GPS not configured — check-in allowed' };
  }
  if (!navigator.geolocation) {
    return { allowed: false, distance: null, reason: 'Geolocation not supported by this device' };
  }
  return new Promise(resolve => {
    navigator.geolocation.getCurrentPosition(
      pos => {
        const dist = Math.round(haversineMetres(pos.coords.latitude, pos.coords.longitude, cfg.lat, cfg.lng));
        const radius = cfg.radius || 100;
        if (dist <= radius) {
          resolve({ allowed: true, distance: dist, reason: `Inside building (${dist}m from centre)` });
        } else {
          resolve({ allowed: false, distance: dist, reason: `You are ${dist}m away — must be within ${radius}m of the building to check in` });
        }
      },
      err => {
        const msgs = { 1:'Location permission denied', 2:'Location unavailable', 3:'Location request timed out' };
        resolve({ allowed: false, distance: null, reason: msgs[err.code] || 'Location error' });
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  });
}

function initMobileSidebar() {
  const sidebar = document.querySelector('.sidebar');
  const main    = document.querySelector('.main');
  if (!sidebar) return;
  const btn = document.createElement('button');
  btn.id = 'hamburgerBtn';
  btn.innerHTML = '☰';
  btn.style.cssText = 'display:none;position:fixed;top:.75rem;left:.75rem;z-index:200;background:#0d1b3e;color:#fff;border:none;border-radius:8px;width:38px;height:38px;font-size:1.3rem;cursor:pointer;align-items:center;justify-content:center;';
  document.body.appendChild(btn);
  const overlay = document.createElement('div');
  overlay.id = 'sidebarOverlay';
  overlay.style.cssText = 'display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:149;';
  document.body.appendChild(overlay);
  function openSidebar()  { sidebar.classList.add('sidebar-open');  overlay.style.display='block'; }
  function closeSidebar() { sidebar.classList.remove('sidebar-open'); overlay.style.display='none'; }
  btn.addEventListener('click', openSidebar);
  overlay.addEventListener('click', closeSidebar);
  document.querySelectorAll('.nav-item').forEach(n => n.addEventListener('click', closeSidebar));
  function applyMobile() {
    const isMobile = window.innerWidth <= 640;
    btn.style.display = isMobile ? 'flex' : 'none';
    if (!isMobile) { sidebar.classList.remove('sidebar-open'); overlay.style.display='none'; }
  }
  window.addEventListener('resize', applyMobile);
  applyMobile();
}

const PROFESSION_ICONS = {
  maid:'🧹', cook:'👨‍🍳', driver:'🚗', gardener:'🌿', plumber:'🔧', electrician:'⚡',
  carpenter:'🪚', watchman:'👁️', delivery:'📦', technician:'🔩', nurse:'🩺', other:'👤'
};
