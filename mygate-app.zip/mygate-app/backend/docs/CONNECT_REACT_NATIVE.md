# How to Wire the React Native App to This Backend

## 1. Change the base URL in every dashboard

Every dashboard currently has a hardcoded URL like:
```js
const response = await fetch(`https://your-api-base-url.com${url}`, options);
// or
const response = await fetch(`http://10.0.2.2:5000${url}`, options);
```

Create a shared API utility file so you only change this in one place:

### `src/utils/api.js`
```js
import AsyncStorage from '@react-native-async-storage/async-storage';

// Android emulator → 10.0.2.2 maps to your machine's localhost
// iOS simulator    → localhost
// Physical device  → your machine's local network IP e.g. 192.168.1.10
const BASE_URL = 'http://10.0.2.2:3000';  // ← app backend port

export const apiFetch = async (url, options = {}) => {
  try {
    const token = await AsyncStorage.getItem('auth_token');
    const response = await fetch(`${BASE_URL}${url}`, {
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(options.headers || {}),
      },
      ...options,
    });
    return await response.json();
  } catch (error) {
    console.error('API Error:', error);
    return null;
  }
};
```

Then in each dashboard replace the local `apiFetch` with:
```js
import { apiFetch } from '../../utils/api';
```

## 2. Store the token after login

In `LoginScreen.js` or `OTPScreen.js`, after a successful login response:
```js
import AsyncStorage from '@react-native-async-storage/async-storage';

// After login API call succeeds:
const data = await apiFetch('/api/v2/auth/login', {
  method: 'POST',
  body: JSON.stringify({ email, password, role: selectedRole }),
});

if (data?.success) {
  await AsyncStorage.setItem('auth_token', data.token);
  await AsyncStorage.setItem('user_role',  data.user.role);
  // Navigate to the correct dashboard
}
```

## 3. Add Socket.IO for real-time updates (optional but recommended)

```bash
npm install socket.io-client
```

Create `src/utils/socket.js`:
```js
import { io } from 'socket.io-client';
import AsyncStorage from '@react-native-async-storage/async-storage';

const BASE_URL = 'http://10.0.2.2:3000';
let socket = null;

export const connectSocket = async () => {
  const token = await AsyncStorage.getItem('auth_token');
  if (!token) return;

  socket = io(BASE_URL);

  socket.on('connect', () => {
    socket.emit('authenticate', { token });
  });

  socket.on('authenticated', (data) => {
    if (!data.success) socket.disconnect();
  });

  return socket;
};

export const getSocket = () => socket;
export const disconnectSocket = () => socket?.disconnect();
```

Use in a dashboard:
```js
import { connectSocket } from '../../utils/socket';

useEffect(() => {
  const setup = async () => {
    const sock = await connectSocket();
    sock?.on('sos:update',         ({ alerts })   => setSosAlerts(alerts));
    sock?.on('maintenance:update', ({ alerts })   => setMaintenanceAlerts(alerts));
    sock?.on('visitor:update',     ({ visitors }) => setRecentVisitors(visitors));
    sock?.on('task:update',        ({ tasks })    => setTasks(tasks));
    sock?.on('approval:update',    ({ approvals }) => {
      approvals.forEach(a => Alert.alert('✅ Visitor Approved', `${a.visitorName} cleared for Flat ${a.apartmentNumber}`));
    });
  };
  setup();
}, []);
```

## 4. API URL reference — all endpoints match your existing screen calls

| Screen | Method | URL | Works? |
|--------|--------|-----|--------|
| AdminDashboard | GET | `/api/v2/sos` | ✅ |
| AdminDashboard | GET | `/api/v2/admin/staff` | ✅ |
| AdminDashboard | GET | `/api/v2/tasks` | ✅ |
| AdminDashboard | PUT | `/api/v2/sos/:id/resolve` | ✅ |
| GuardDashboard | GET | `/api/v2/admin/visitors` | ✅ |
| GuardDashboard | GET | `/api/v2/maintenance` | ✅ |
| GuardDashboard | GET | `/api/v2/sos` | ✅ |
| GuardDashboard | POST | `/api/v2/guard/check-in` | ✅ |
| GuardDashboard | POST | `/api/v2/guard/check-out` | ✅ |
| GuardDashboard | POST | `/api/v2/guard/register-visitor` | ✅ |
| ResidentDashboard | POST | `/api/v2/sos` | ✅ |
| ResidentDashboard | POST | `/api/v2/resident/hire-maid` | ✅ |
| ResidentDashboard | POST | `/api/v2/tasks` | ✅ |
| ResidentDashboard | PUT | `/api/v2/admin/visitors/:id/status` | ✅ |
| MaidDashboard | GET | `/api/v2/maintenance` | ✅ |
| MaidDashboard | GET | `/api/v2/tasks?assignTo=maid` | ✅ |
| StaffDashboard | GET | `/api/v2/tasks` | ✅ |
| StaffDashboard | PUT | `/api/v2/tasks/:id` | ✅ |
| StaffDashboard | POST | `/api/v2/staff/check-in` | ✅ |
| LoginScreen | POST | `/api/v2/auth/login` | ✅ |
| RegisterScreen | POST | `/api/v2/auth/register` | ✅ |
