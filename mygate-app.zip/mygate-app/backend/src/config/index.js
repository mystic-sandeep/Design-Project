require('dotenv').config();

if (!process.env.JWT_SECRET) {
  process.stderr.write('[WARN] JWT_SECRET not set in environment. Using default key — set this in production.\n');
}

module.exports = {
  port: parseInt(process.env.PORT || '3000', 10),
  websiteBackendUrl: process.env.WEBSITE_BACKEND_URL || 'http://localhost:8080',
  jwtSecret: process.env.JWT_SECRET || 'mygate_2026_secure_key_layer1_jwt_authentication_system_very_long_string_to_make_it_secure_enough_for_hs512_algorithm',
  syncIntervalMs: parseInt(process.env.SYNC_INTERVAL_MS || '3000', 10),
  allowedOrigins: (process.env.ALLOWED_ORIGINS || '*').split(',').map(s => s.trim()),
};
