const jwt = require('jsonwebtoken');
const { jwtSecret } = require('../config');

function authMiddleware(req, res, next) {
  const header = req.headers['authorization'];
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, error: 'Authorization token missing' });
  }
  try {
    const decoded = jwt.verify(header.slice(7), jwtSecret, { algorithms: ['HS512'] });
    req.user  = { id: decoded.sub, email: decoded.email, role: decoded.role };
    req.token = header.slice(7);
    next();
  } catch {
    return res.status(401).json({ success: false, error: 'Invalid or expired token' });
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ success: false, error: 'Not authenticated' });
    if (roles.map(r => r.toLowerCase()).includes((req.user.role || '').toLowerCase())) return next();
    return res.status(403).json({ success: false, error: `Access denied. Required: ${roles.join(', ')}` });
  };
}

module.exports = { authMiddleware, requireRole };
