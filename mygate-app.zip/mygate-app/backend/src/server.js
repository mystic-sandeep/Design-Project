require('dotenv').config();
const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const cors       = require('cors');
const helmet     = require('helmet');
const morgan     = require('morgan');
const rateLimit  = require('express-rate-limit');
const jwt        = require('jsonwebtoken');

const config      = require('./config');
const syncService = require('./services/syncService');
const wc          = require('./services/websiteClient');

const authRoutes         = require('./routes/auth');
const sosRoutes          = require('./routes/sos');
const maintenanceRoutes  = require('./routes/maintenance');
const visitorRoutes      = require('./routes/visitors');
const taskRoutes         = require('./routes/tasks');
const staffRoutes        = require('./routes/staff');
const guardRoutes        = require('./routes/guard');
const residentRoutes     = require('./routes/resident');
const adminRoutes        = require('./routes/admin');
const guestRoutes        = require('./routes/guests');
const complaintRoutes    = require('./routes/complaints');
const facilityRoutes     = require('./routes/facilities');
const announcementRoutes = require('./routes/announcements');

const app    = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: config.allowedOrigins, methods: ['GET', 'POST'] },
});

app.use(helmet());
app.use(cors({ origin: config.allowedOrigins }));
app.use(express.json());
app.use(morgan('dev'));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 200, standardHeaders: true, legacyHeaders: false }));

app.use('/api/v2/auth', authRoutes);
app.use('/api/auth',    authRoutes);
app.use('/api/v2/sos', sosRoutes);
app.use('/api/v2/maintenance', maintenanceRoutes);
app.use('/api/v2', visitorRoutes);
app.use('/api/v2/tasks', taskRoutes);
app.use('/api/v2', staffRoutes);
app.use('/api/v2/guard', guardRoutes);
app.use('/api/v2/resident', residentRoutes);
app.use('/api/v2/admin', adminRoutes);
app.use('/api/admin',    adminRoutes);
app.use('/api/v2/complaints', complaintRoutes);
app.use('/api/guests', guestRoutes);
app.use('/api/v2/facilities', facilityRoutes);
app.use('/api/v2/announcements', announcementRoutes);

app.get('/health', (req, res) => res.json({
  status: 'ok',
  service: 'MyGate App Backend',
  websiteBackend: config.websiteBackendUrl,
  syncInterval: `${config.syncIntervalMs}ms`,
  time: new Date().toISOString(),
}));

app.use((req, res) => res.status(404).json({ success: false, error: `Route not found: ${req.method} ${req.path}` }));

io.on('connection', (socket) => {
  const authTimeout = setTimeout(() => socket.disconnect(true), 10_000);

  socket.on('authenticate', ({ token }) => {
    try {
      const decoded = jwt.verify(token, config.jwtSecret, { algorithms: ['HS512'] });
      clearTimeout(authTimeout);
      socket.user = { id: decoded.sub, email: decoded.email, role: decoded.role };
      socket.join(socket.user.role.toLowerCase());
      socket.emit('authenticated', { success: true, user: socket.user });
    } catch {
      socket.emit('authenticated', { success: false, error: 'Invalid token' });
      socket.disconnect(true);
    }
  });

  socket.on('sync:request', async ({ resource }) => {
    if (!socket.user) return;
    try {
      if (resource === 'sos')         { const d = await wc.getSos(null);              socket.emit('sos:update', d.data || {}); }
      if (resource === 'maintenance') { const d = await wc.getMaintenance(null);      socket.emit('maintenance:update', d.data || {}); }
      if (resource === 'visitors')    { const d = await wc.getPendingVisitors(null);  socket.emit('visitor:update', d.data || {}); }
      if (resource === 'tasks')       { const d = await wc.getTasks(null);            socket.emit('task:update', d.data || {}); }
    } catch (_) {}
  });

  socket.on('disconnect', () => {
    clearTimeout(authTimeout);
  });
});

server.listen(config.port, async () => {
  try {
    const r = await wc.login('admin@mygate.com', 'admin123', 'admin');
    if (r.success) {
      syncService.start(io, r.token);
    }
  } catch (_) {}
});

module.exports = { app, server, io };
