const router = require('express').Router();
const wc = require('../services/websiteClient');
const { authMiddleware } = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  try {
    const qs = req.query.status ? `?status=${req.query.status}` : '';
    return res.json(await wc.get(`/api/v2/facilities${qs}`, req.token));
  } catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.get('/by-flat/:flat', async (req, res) => {
  try {
    return res.json(await wc.get(`/api/v2/facilities/by-flat/${req.params.flat}`, req.token));
  } catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/', async (req, res) => {
  try {
    return res.json(await wc.post('/api/v2/facilities', req.body, req.token));
  } catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.put('/:id/status', async (req, res) => {
  try {
    return res.json(await wc.put(`/api/v2/facilities/${req.params.id}/status`, req.body, req.token));
  } catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    return res.json(await wc.delete(`/api/v2/facilities/${req.params.id}`, req.token));
  } catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

module.exports = router;
