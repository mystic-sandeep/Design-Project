const router = require('express').Router();
const wc = require('../services/websiteClient');
const { authMiddleware, requireRole } = require('../middleware/auth');

router.use(authMiddleware);

router.get('/admin/staff', requireRole('admin'), async (req, res) => {
  try { return res.json(await wc.getStaff(req.token)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.get('/staff/today', requireRole('admin'), async (req, res) => {
  try { return res.json(await wc.getStaff(req.token)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/staff/check-in', requireRole('staff', 'maid', 'guard', 'admin'), async (req, res) => {
  try { return res.json(await wc.guardCheckIn(req.token, req.body)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/staff/check-out', requireRole('staff', 'maid', 'guard', 'admin'), async (req, res) => {
  try { return res.json(await wc.guardCheckOut(req.token)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

module.exports = router;
