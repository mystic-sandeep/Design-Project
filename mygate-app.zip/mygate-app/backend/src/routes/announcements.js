const router = require('express').Router();
const wc = require('../services/websiteClient');
const { authMiddleware } = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  try {
    const qs = req.query.category ? `?category=${req.query.category}` : '';
    return res.json(await wc.get(`/api/v2/announcements${qs}`, req.token));
  } catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/', async (req, res) => {
  try {
    return res.json(await wc.post('/api/v2/announcements', req.body, req.token));
  } catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    return res.json(await wc.delete(`/api/v2/announcements/${req.params.id}`, req.token));
  } catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

module.exports = router;
