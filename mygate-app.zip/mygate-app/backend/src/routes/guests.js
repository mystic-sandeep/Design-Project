const router = require('express').Router();
const wc = require('../services/websiteClient');

router.post('/verify', async (req, res) => {
  const { passCode } = req.body;
  if (!passCode) return res.status(400).json({ success: false, error: 'passCode required' });
  try { return res.json(await wc.verifyPasscode(passCode)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

module.exports = router;
