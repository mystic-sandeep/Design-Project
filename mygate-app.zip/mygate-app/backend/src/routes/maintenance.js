const router = require('express').Router();
const wc = require('../services/websiteClient');
const { authMiddleware, requireRole } = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  try { return res.json(await wc.getMaintenance(req.token)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/', requireRole('admin'), async (req, res) => {
  try { return res.json(await wc.createMaintenance(req.token, req.body)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.delete('/:id', requireRole('admin'), async (req, res) => {
  try { return res.json(await wc.deleteMaintenance(req.token, req.params.id)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

module.exports = router;
