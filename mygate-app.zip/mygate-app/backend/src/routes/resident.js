const router = require('express').Router();
const wc = require('../services/websiteClient');
const { authMiddleware, requireRole } = require('../middleware/auth');

router.use(authMiddleware);
router.use(requireRole('resident', 'admin'));

router.get('/bills', async (req, res) => {
  try { return res.json(await wc.getBills(req.token)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/hire-maid', async (req, res) => {
  try { return res.json(await wc.hireMaid(req.token, req.body)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/file-complaint', async (req, res) => {
  try { return res.json(await wc.fileComplaint(req.token, req.body)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/manage-vehicles', async (req, res) => {
  try { return res.json(await wc.manageVehicles(req.token, req.body)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

module.exports = router;
