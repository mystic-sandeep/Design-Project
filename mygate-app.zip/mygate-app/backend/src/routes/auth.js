const router = require('express').Router();
const wc = require('../services/websiteClient');
const { authMiddleware } = require('../middleware/auth');

router.post('/login', async (req, res) => {
  const { email, password, role } = req.body || {};
  if (!email || !password)
    return res.status(400).json({ success: false, error: 'email and password required' });
  try {
    const data = await wc.login(email, password, role || 'resident');
    return res.status(data.success ? 200 : 401).json(data);
  } catch (e) {
    return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message });
  }
});

router.post('/register', async (req, res) => {
  try {
    const data = await wc.register(req.body);
    return res.status(data.success ? 200 : 400).json(data);
  } catch (e) {
    return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message });
  }
});

router.post('/verify', authMiddleware, async (req, res) => {
  try {
    const data = await wc.verify(req.token);
    return res.json(data);
  } catch (e) {
    return res.status(401).json({ success: false, error: 'Token invalid' });
  }
});

module.exports = router;
