const router = require('express').Router();
const wc = require('../services/websiteClient');
const { authMiddleware, requireRole } = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', requireRole('admin'), async (req, res) => {
  try {
    return res.json(await wc.getComplaints(req.token, req.query));
  } catch (e) {
    return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message });
  }
});

router.post('/', requireRole('resident', 'admin'), async (req, res) => {
  try {
    return res.json(await wc.fileComplaintV2(req.token, req.body));
  } catch (e) {
    return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message });
  }
});

router.put('/:id/resolve', requireRole('admin'), async (req, res) => {
  try {
    return res.json(await wc.resolveComplaint(req.token, req.params.id));
  } catch (e) {
    return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message });
  }
});

router.delete('/:id', requireRole('admin'), async (req, res) => {
  try {
    return res.json(await wc.deleteComplaint(req.token, req.params.id));
  } catch (e) {
    return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message });
  }
});

module.exports = router;
