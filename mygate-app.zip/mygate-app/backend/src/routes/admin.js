const router = require('express').Router();
const wc = require('../services/websiteClient');
const { authMiddleware, requireRole } = require('../middleware/auth');

router.use(authMiddleware);
router.use(requireRole('admin'));

router.get('/stats', async (req, res) => {
  try { return res.json(await wc.getAdminStats(req.token)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.get('/residents', async (req, res) => {
  try { return res.json(await wc.getResidents(req.token)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.get('/pending', async (req, res) => {
  try { return res.json(await wc.getPendingUsers(req.token)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.put('/approve/:id', async (req, res) => {
  try { return res.json(await wc.approveUser(req.token, req.params.id)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

module.exports = router;
