const router = require('express').Router();
const wc = require('../services/websiteClient');
const { authMiddleware, requireRole } = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  try { return res.json(await wc.getSos(req.token)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/', requireRole('resident', 'admin'), async (req, res) => {
  const body = {
    resident: req.body.resident || req.user.email,
    flat:     req.body.flat    || '',
    message:  req.body.message || 'Emergency! Please send help.',
  };
  try { return res.json(await wc.sendSos(req.token, body)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.put('/:id/resolve', requireRole('admin', 'guard'), async (req, res) => {
  try { return res.json(await wc.resolveSos(req.token, req.params.id)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

module.exports = router;
