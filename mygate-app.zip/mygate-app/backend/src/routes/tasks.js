const router = require('express').Router();
const wc = require('../services/websiteClient');
const { authMiddleware } = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  const query = req.query.assignTo ? `?assignTo=${req.query.assignTo}` : '';
  try { return res.json(await wc.getTasks(req.token, query)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.get('/pending-otps', async (req, res) => {
  const query = req.query.recipient ? `?recipient=${req.query.recipient}` : '';
  try { return res.json(await wc.getPendingOtps(req.token, query)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/', async (req, res) => {
  try { return res.json(await wc.createTask(req.token, req.body)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.put('/:id', async (req, res) => {
  try { return res.json(await wc.updateTask(req.token, req.params.id, req.body)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/:id/accept', async (req, res) => {
  try { return res.json(await wc.acceptTask(req.token, req.params.id, req.body)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/:id/request-otp', async (req, res) => {
  try { return res.json(await wc.requestTaskOtp(req.token, req.params.id, req.body)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/:id/verify-otp', async (req, res) => {
  try { return res.json(await wc.verifyTaskOtp(req.token, req.params.id, req.body)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.delete('/:id', async (req, res) => {
  try { return res.json(await wc.deleteTask(req.token, req.params.id)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

module.exports = router;
