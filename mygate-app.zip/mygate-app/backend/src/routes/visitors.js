const router = require('express').Router();
const wc = require('../services/websiteClient');
const { authMiddleware, requireRole } = require('../middleware/auth');

router.use(authMiddleware);

router.get('/admin/visitors', requireRole('admin', 'guard'), async (req, res) => {
  try { return res.json(await wc.getAllVisitors(req.token)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.put('/admin/visitors/:id/status', requireRole('admin', 'resident'), async (req, res) => {
  try { return res.json(await wc.updateVisitorStatus(req.token, req.params.id, req.body.status)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.get('/guard/pending-visitors', requireRole('guard', 'admin'), async (req, res) => {
  try { return res.json(await wc.getPendingVisitors(req.token)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/guard/register-visitor', requireRole('guard', 'admin'), async (req, res) => {
  try { return res.json(await wc.registerVisitor(req.token, req.body)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.get('/guard/poll-approvals', requireRole('guard', 'admin'), async (req, res) => {
  try { return res.json(await wc.pollApprovals(req.token)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

router.post('/resident/approve-visitor', requireRole('resident', 'admin'), async (req, res) => {
  const { passCode } = req.body;
  if (!passCode) return res.status(400).json({ success: false, error: 'passCode required' });
  try { return res.json(await wc.approveVisitor(req.token, passCode)); }
  catch (e) { return res.status(e.response?.status || 500).json(e.response?.data || { success: false, error: e.message }); }
});

module.exports = router;
