const wc = require('./websiteClient');
const { syncIntervalMs } = require('../config');

let _io          = null;
let _systemToken = null;

const hashes = { sos: '', maintenance: '', visitors: '', tasks: '' };

function hash(arr) {
  if (!arr || !arr.length) return '[]';
  return `${arr.length}::${JSON.stringify(arr[0])}`;
}

async function syncSos() {
  try {
    const d = await wc.getSos(_systemToken);
    const alerts = d?.data?.alerts || [];
    const h = hash(alerts);
    if (h !== hashes.sos) { hashes.sos = h; _io.emit('sos:update', { alerts }); }
  } catch (_) {}
}

async function syncMaintenance() {
  try {
    const d = await wc.getMaintenance(_systemToken);
    const alerts = d?.data?.alerts || [];
    const h = hash(alerts);
    if (h !== hashes.maintenance) { hashes.maintenance = h; _io.emit('maintenance:update', { alerts }); }
  } catch (_) {}
}

async function syncVisitors() {
  try {
    const d = await wc.getPendingVisitors(_systemToken);
    const visitors = d?.data?.visitors || [];
    const h = hash(visitors);
    if (h !== hashes.visitors) { hashes.visitors = h; _io.emit('visitor:update', { visitors }); }
  } catch (_) {}
}

async function syncApprovals() {
  try {
    const d = await wc.pollApprovals(_systemToken);
    const approvals = d?.data?.approvals || [];
    if (approvals.length > 0) _io.emit('approval:update', { approvals });
  } catch (_) {}
}

async function syncTasks() {
  try {
    const d = await wc.getTasks(_systemToken);
    const tasks = d?.data?.tasks || [];
    const h = hash(tasks);
    if (h !== hashes.tasks) { hashes.tasks = h; _io.emit('task:update', { tasks }); }
  } catch (_) {}
}

function start(io, systemToken) {
  _io = io;
  _systemToken = systemToken;
  setInterval(async () => {
    await syncSos();
    await syncMaintenance();
    await syncVisitors();
    await syncApprovals();
    await syncTasks();
  }, syncIntervalMs);
}

module.exports = { start };
