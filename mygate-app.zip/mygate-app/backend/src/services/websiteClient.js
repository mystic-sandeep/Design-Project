const axios = require('axios');
const { websiteBackendUrl } = require('../config');

const http = axios.create({
  baseURL: websiteBackendUrl,
  timeout: 8000,
  headers: { 'Content-Type': 'application/json' },
});

const auth = (token) => token ? { Authorization: `Bearer ${token}` } : {};

const login    = (email, password, role) => http.post('/api/auth/login', { email, password, role }).then(r => r.data);
const register = (body)                  => http.post('/api/auth/register', body).then(r => r.data);
const verify   = (token)                 => http.post('/api/auth/verify', {}, { headers: auth(token) }).then(r => r.data);

const getSos     = (token)      => http.get ('/api/v2/sos',              { headers: auth(token) }).then(r => r.data);
const sendSos    = (token, body) => http.post('/api/v2/sos', body,        { headers: auth(token) }).then(r => r.data);
const resolveSos = (token, id)   => http.put (`/api/v2/sos/${id}/resolve`,{}, { headers: auth(token) }).then(r => r.data);

const getMaintenance    = (token)      => http.get   ('/api/v2/maintenance',     { headers: auth(token) }).then(r => r.data);
const createMaintenance = (token, body) => http.post  ('/api/v2/maintenance', body, { headers: auth(token) }).then(r => r.data);
const deleteMaintenance = (token, id)   => http.delete(`/api/v2/maintenance/${id}`, { headers: auth(token) }).then(r => r.data);

const getPendingVisitors  = (token)      => http.get ('/api/v2/guard/pending-visitors',      { headers: auth(token) }).then(r => r.data);
const getAllVisitors       = (token)      => http.get ('/api/v2/admin/visitors',              { headers: auth(token) }).then(r => r.data);
const registerVisitor     = (token, body) => http.post('/api/v2/guard/register-visitor', body, { headers: auth(token) }).then(r => r.data);
const approveVisitor      = (token, code) => http.post('/api/v2/resident/approve-visitor', { passCode: code }, { headers: auth(token) }).then(r => r.data);
const updateVisitorStatus = (token, id, status) =>
  http.put(`/api/v2/admin/visitors/${id}/status`, { status }, { headers: auth(token) }).then(r => r.data);
const verifyPasscode      = (code)       => http.post('/api/guests/verify', { passCode: code }).then(r => r.data);
const pollApprovals       = (token)      => http.get ('/api/v2/guard/poll-approvals', { headers: auth(token) }).then(r => r.data);

const getTasks       = (token, query = '') => http.get (`/api/v2/tasks${query}`,               { headers: auth(token) }).then(r => r.data);
const createTask     = (token, body)       => http.post('/api/v2/tasks', body,                 { headers: auth(token) }).then(r => r.data);
const updateTask     = (token, id, body)   => http.put (`/api/v2/tasks/${id}/status`, body,    { headers: auth(token) }).then(r => r.data);
const acceptTask     = (token, id, body)   => http.post(`/api/v2/tasks/${id}/accept`, body||{},{ headers: auth(token) }).then(r => r.data);
const requestTaskOtp = (token, id, body)   => http.post(`/api/v2/tasks/${id}/request-otp`, body||{}, { headers: auth(token) }).then(r => r.data);
const verifyTaskOtp  = (token, id, body)   => http.post(`/api/v2/tasks/${id}/verify-otp`, body,{ headers: auth(token) }).then(r => r.data);
const getPendingOtps = (token, query = '') => http.get (`/api/v2/tasks/pending-otps${query}`,  { headers: auth(token) }).then(r => r.data);
const deleteTask     = (token, id)         => http.delete(`/api/v2/tasks/${id}`,               { headers: auth(token) }).then(r => r.data);

const getStaff    = (token) => http.get('/api/v2/admin/staff',   { headers: auth(token) }).then(r => r.data)
  .catch(() => http.get('/api/v2/staff/today', { headers: auth(token) }).then(r => r.data));

const getBills       = (token)      => http.get ('/api/v2/resident/bills',            { headers: auth(token) }).then(r => r.data);
const hireMaid       = (token, body) => http.post('/api/v2/resident/hire-maid', body,  { headers: auth(token) }).then(r => r.data);
const fileComplaint  = (token, body) => http.post('/api/v2/resident/file-complaint', body, { headers: auth(token) }).then(r => r.data);
const manageVehicles = (token, body) => http.post('/api/v2/resident/manage-vehicles', body, { headers: auth(token) }).then(r => r.data);

const getComplaints     = (token, query = {}) => {
  const qs = query.status ? `?status=${query.status}` : '';
  return http.get(`/api/v2/complaints${qs}`, { headers: auth(token) }).then(r => r.data);
};
const fileComplaintV2   = (token, body) => http.post('/api/v2/complaints', body, { headers: auth(token) }).then(r => r.data);
const resolveComplaint  = (token, id)   => http.put(`/api/v2/complaints/${id}/resolve`, {}, { headers: auth(token) }).then(r => r.data);
const deleteComplaint   = (token, id)   => http.delete(`/api/v2/complaints/${id}`, { headers: auth(token) }).then(r => r.data);

const guardCheckIn  = (token, body) => http.post('/api/v2/guard/check-in',   body || {}, { headers: auth(token) }).then(r => r.data);
const guardCheckOut = (token)       => http.post('/api/v2/guard/check-out',  {},          { headers: auth(token) }).then(r => r.data);
const logVehicle    = (token, body) => http.post('/api/v2/guard/log-vehicle', body,        { headers: auth(token) }).then(r => r.data);

const getAdminStats    = (token) => http.get('/api/v2/admin/stats',     { headers: auth(token) }).then(r => r.data);
const getResidents     = (token) => http.get('/api/v2/admin/residents', { headers: auth(token) }).then(r => r.data);
const getPendingUsers  = (token) => http.get('/api/v2/admin/registrations/pending', { headers: auth(token) }).then(r => r.data);
const approveUser      = (token, id) => http.put(`/api/v2/admin/registrations/${id}/status`, { status: 'APPROVED' }, { headers: auth(token) }).then(r => r.data);

const get    = (url, token)       => http.get   (url,       { headers: auth(token) }).then(r => r.data);
const post   = (url, body, token) => http.post  (url, body, { headers: auth(token) }).then(r => r.data);
const put    = (url, body, token) => http.put   (url, body, { headers: auth(token) }).then(r => r.data);
const del    = (url, token)       => http.delete(url,       { headers: auth(token) }).then(r => r.data);

module.exports = {

  login, register, verify,

  getSos, sendSos, resolveSos,

  getMaintenance, createMaintenance, deleteMaintenance,

  getPendingVisitors, getAllVisitors, registerVisitor, approveVisitor,
  updateVisitorStatus, verifyPasscode, pollApprovals,

  getTasks, createTask, updateTask, acceptTask, requestTaskOtp, verifyTaskOtp, getPendingOtps, deleteTask,

  getStaff,

  getBills, hireMaid, fileComplaint, manageVehicles,

  getComplaints, fileComplaintV2, resolveComplaint, deleteComplaint,

  guardCheckIn, guardCheckOut, logVehicle,

  getAdminStats, getResidents, getPendingUsers, approveUser,

  get, post, put, delete: del,
};
