import React, { useState, useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import AppNavigator from './src/navigation/AppNavigator';

export default function App() {
  const [userRole, setUserRole] = useState<string | null>(null);
  const [bootstrapping, setBootstrapping] = useState(true);

  useEffect(() => {
    const restore = async () => {
      try {
        const role = await AsyncStorage.getItem('@mygate_role');
        if (role) setUserRole(role);
      } catch (_) {}
      setBootstrapping(false);
    };
    restore();
  }, []);

  const handleLoginSuccess = async (role: string) => {
    await AsyncStorage.setItem('@mygate_role', role);
    setUserRole(role);
  };

  const handleLogout = async () => {
    await AsyncStorage.multiRemove(['@mygate_token', '@mygate_role']);
    setUserRole(null);
  };

  if (bootstrapping) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' }}>
        <ActivityIndicator size="large" color="#0a4a4a" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <AppNavigator
        userRole={userRole}
        onLoginSuccess={handleLoginSuccess}
        onLogout={handleLogout}
      />
    </NavigationContainer>
  );
}
