import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert
} from 'react-native';
import { COLORS } from '../../constants/theme';
import { apiFetch } from '../../api/client';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function StaffDashboard({ navigation }) {
  const [checkedIn, setCheckedIn] = useState(false);
  const [buildingAccess, setBuildingAccess] = useState(false);
  const [isLocating, setIsLocating] = useState(false);
  const [loading, setLoading] = useState(true);
  const [tasks, setTasks] = useState([]);
  const [counts, setCounts] = useState({ pending: 0, accepted: 0, done: 0 });

  useEffect(() => {
    fetchTasks();
    const poll = setInterval(fetchTasks, 30000);
    return () => clearInterval(poll);
  }, []);

  const fetchTasks = async () => {
    setLoading(true);
    try {
      const d = await apiFetch('/api/v2/tasks?assignTo=staff');
      const list = d?.data?.tasks || d?.data || [];
      setTasks(list);
      setCounts({
        pending:  list.filter(t => t.status === 'pending').length,
        accepted: list.filter(t => ['accepted','otp_pending'].includes(t.status)).length,
        done:     list.filter(t => t.status === 'done').length,
      });
    } catch (e) {
      Alert.alert('Error', 'Failed to load tasks.');
    } finally {
      setLoading(false);
    }
  };

  const handleCheckIn = async () => {
    setIsLocating(true);
    try {

      const savedName = await AsyncStorage.getItem('@mygate_name') || 'Staff';
      const savedFlat = await AsyncStorage.getItem('@mygate_apartment') || '';

      const res = await apiFetch('/api/v2/staff/check-in', {
        method: 'POST',
        body: JSON.stringify({
          name: savedName,
          type: 'staff',
          flat: savedFlat,
          gps_lat: null,
          gps_lng: null,
          gps_distance: null
        })
      });
      if (res && res.data && res.data.id) {
        await AsyncStorage.setItem('staff_record_id', String(res.data.id));
      }
      setCheckedIn(true);
      Alert.alert('Success', 'Checked in ✅ — attendance recorded');
    } catch (e) {
      Alert.alert('Error', 'Failed to record check-in. Please try again.');
    } finally {
      setIsLocating(false);
    }
  };

  const handleAccessBuilding = () => {
    setBuildingAccess(true);
    Alert.alert('Access Granted', 'Building access granted 🏢');
  };

  const handleCheckOut = async () => {
    try {
      await apiFetch('/api/v2/staff/check-out', { method: 'POST' });
    } catch (e) {  }
    setCheckedIn(false);
    setBuildingAccess(false);
    await AsyncStorage.removeItem('staff_record_id');
    Alert.alert('Shift Ended', 'Checkout recorded.');
  };

  const acceptTask = async (id) => {
    if (!checkedIn || !buildingAccess) {
      Alert.alert('Access Denied', '🔒 Check In and Access Building before handling tasks.');
      return;
    }
    const res = await apiFetch(`/api/v2/tasks/${id}/accept`, { method: 'POST' });
    if (res?.success) fetchTasks();
    else Alert.alert('Error', res?.error || 'Failed to accept task.');
  };

  const requestOtp = async (id) => {
    const res = await apiFetch(`/api/v2/tasks/${id}/request-otp`, {
      method: 'POST',
      body: JSON.stringify({ otpRecipient: 'resident' })
    });
    if (res?.success) {
      Alert.alert(
        '🔑 OTP Generated',
        `OTP sent to resident.\n\nDemo OTP: ${res?.data?.otp || '—'}\nExpires in 10 minutes.`
      );
      fetchTasks();
    } else {
      Alert.alert('Error', res?.error || 'Failed to request OTP.');
    }
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color={COLORS.primary || '#4f46e5'} />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 30 }}>

      <View style={styles.shiftCard}>
        <Text style={styles.cardHeaderTitle}>👷 My Shift</Text>

        <View style={styles.stepperContainer}>
          <Text style={[styles.stepText, checkedIn && styles.stepDone]}>1️⃣ In</Text>
          <Text style={styles.arrow}>→</Text>
          <Text style={[styles.stepText, buildingAccess && styles.stepDone, !buildingAccess && checkedIn && styles.stepActive]}>2️⃣ Access</Text>
          <Text style={styles.arrow}>→</Text>
          <Text style={[styles.stepText, buildingAccess && styles.stepActive]}>3️⃣ Tasks</Text>
        </View>

        <View style={styles.btnRow}>
          <TouchableOpacity
            style={[styles.btn, styles.btnSuccess, checkedIn && styles.btnDisabled]}
            onPress={handleCheckIn}
            disabled={checkedIn || isLocating}
          >
            {isLocating ? <ActivityIndicator size="small" color="#fff" /> : <Text style={styles.btnText}>✓ Check In</Text>}
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.btn, styles.btnOutline, (!checkedIn || buildingAccess) && styles.btnDisabled]}
            onPress={handleAccessBuilding}
            disabled={!checkedIn || buildingAccess}
          >
            <Text style={styles.btnText}>🏢 Access Bldg</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.btn, styles.btnWarning, !checkedIn && styles.btnDisabled]}
            onPress={handleCheckOut}
            disabled={!checkedIn}
          >
            <Text style={styles.btnText}>Exit Shift</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.shiftInfo}>
          {checkedIn
            ? (buildingAccess ? '🟢 Inside building — view tasks' : '🟡 Checked in — tap "Access Building"')
            : '⚪ Not checked in'}
        </Text>
      </View>

      <View style={styles.statsRow}>
        <View style={styles.statCard}><Text style={styles.statIcon}>⏳</Text><Text style={styles.statNum}>{counts.pending}</Text><Text style={styles.statLbl}>Pending</Text></View>
        <View style={styles.statCard}><Text style={styles.statIcon}>🔄</Text><Text style={styles.statNum}>{counts.accepted}</Text><Text style={styles.statLbl}>Progress</Text></View>
        <View style={styles.statCard}><Text style={styles.statIcon}>✅</Text><Text style={styles.statNum}>{counts.done}</Text><Text style={styles.statLbl}>Completed</Text></View>
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>✅ Assigned Tasks ({tasks.length})</Text>
        {tasks.length === 0 ? (
          <Text style={styles.emptyText}>No tasks assigned yet.</Text>
        ) : (
          tasks.map((task) => (
            <View key={task.id} style={styles.taskCard}>
              <View style={[styles.priorityIndicator, { backgroundColor: task.priority === 'high' ? '#dc2626' : '#eab308' }]} />
              <View style={styles.taskInfo}>
                <Text style={styles.taskTitle}>{task.title}</Text>
                <Text style={styles.taskMeta}>{task.location} • By: {task.createdBy}</Text>
                <View style={styles.badgeRow}>
                  <View style={[styles.badge, { backgroundColor: task.status === 'accepted' ? '#dbeafe' : task.status === 'otp_pending' ? '#fef3c7' : task.status === 'done' ? '#dcfce7' : '#f3f4f6' }]}>
                    <Text style={styles.badgeText}>{task.status === 'otp_pending' ? 'OTP SENT 🔑' : task.status.toUpperCase()}</Text>
                  </View>
                </View>
                {task.status === 'otp_pending' && (
                  <Text style={styles.otpHint}>⏳ Waiting for resident to verify OTP</Text>
                )}
              </View>
              <View style={styles.taskActions}>
                {task.status === 'pending' && (
                  <TouchableOpacity style={[styles.actionBtn, styles.btnPrimary]} onPress={() => acceptTask(task.id)}>
                    <Text style={styles.actionBtnText}>Accept</Text>
                  </TouchableOpacity>
                )}
                {task.status === 'accepted' && (
                  <TouchableOpacity style={[styles.actionBtn, { backgroundColor: '#f59e0b' }]} onPress={() => requestOtp(task.id)}>
                    <Text style={styles.actionBtnText}>Request OTP 🔑</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          ))
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:          { flex: 1, backgroundColor: '#f9fafb', padding: 14 },
  centered:           { flex: 1, justifyContent: 'center', alignItems: 'center' },
  shiftCard:          { backgroundColor: '#1e1b4b', borderRadius: 12, padding: 16, marginBottom: 16 },
  cardHeaderTitle:    { color: '#fff', fontSize: 18, fontWeight: '800', marginBottom: 12 },
  stepperContainer:   { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  stepText:           { color: 'rgba(255,255,255,0.4)', fontSize: 13, fontWeight: '600' },
  stepActive:         { color: '#f59e0b', fontWeight: '800' },
  stepDone:           { color: '#22c55e', textDecorationLine: 'line-through' },
  arrow:              { color: 'rgba(255,255,255,0.3)' },
  btnRow:             { flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginBottom: 12 },
  btn:                { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 6, minWidth: 90, alignItems: 'center', justifyContent: 'center' },
  btnSuccess:         { backgroundColor: '#16a34a' },
  btnWarning:         { backgroundColor: '#f59e0b' },
  btnOutline:         { borderWidth: 1, borderColor: 'rgba(255,255,255,0.4)' },
  btnDisabled:        { opacity: 0.35 },
  btnText:            { color: '#fff', fontSize: 12, fontWeight: '700' },
  shiftInfo:          { color: 'rgba(255,255,255,0.8)', fontSize: 12, marginTop: 4 },
  statsRow:           { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 16, gap: 8 },
  statCard:           { flex: 1, backgroundColor: '#fff', borderRadius: 10, padding: 12, alignItems: 'center', borderWidth: 1, borderColor: '#e5e7eb' },
  statIcon:           { fontSize: 20, marginBottom: 4 },
  statNum:            { fontSize: 18, fontWeight: '700', color: '#111827' },
  statLbl:            { fontSize: 11, color: '#6b7280' },
  card:               { backgroundColor: '#fff', borderRadius: 12, padding: 16, borderWidth: 1, borderColor: '#e5e7eb' },
  sectionTitle:       { fontSize: 15, fontWeight: '700', color: '#111827', marginBottom: 12 },
  emptyText:          { color: '#9ca3af', fontSize: 13, textAlign: 'center', paddingVertical: 16 },
  taskCard:           { flexDirection: 'row', backgroundColor: '#f9fafb', borderRadius: 8, padding: 12, marginBottom: 10, position: 'relative', overflow: 'hidden' },
  priorityIndicator:  { position: 'absolute', left: 0, top: 0, bottom: 0, width: 4 },
  taskInfo:           { flex: 2, paddingLeft: 6 },
  taskTitle:          { fontSize: 14, fontWeight: '600', color: '#111827' },
  taskMeta:           { fontSize: 11, color: '#6b7280', marginTop: 2 },
  badgeRow:           { flexDirection: 'row', marginTop: 6 },
  badge:              { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  badgeText:          { fontSize: 9, fontWeight: '700', color: '#374151' },
  otpHint:            { fontSize: 11, color: '#d97706', marginTop: 4, fontWeight: '600' },
  taskActions:        { flex: 1, justifyContent: 'center', alignItems: 'flex-end' },
  actionBtn:          { paddingVertical: 6, paddingHorizontal: 10, borderRadius: 6 },
  actionBtnText:      { color: '#fff', fontSize: 12, fontWeight: '600' },
  btnPrimary:         { backgroundColor: '#4f46e5' },
});
