import React, { useState, useEffect } from 'react';
import { apiFetch } from '../../api/client';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DateTimePicker from '@react-native-community/datetimepicker';
import {
  StyleSheet, View, Text, TouchableOpacity, ScrollView,
  TextInput, Modal, Alert, ActivityIndicator, Platform
} from 'react-native';
import { COLORS } from '../../constants/theme';

export default function ResidentDashboard({ navigation, onLogout }) {

  const [activeTab, setActiveTab] = useState('home');
  const [user, setUser] = useState({ name: 'Resident', apartment: '', email: '' });

  const [visitors, setVisitors]       = useState([]);
  const [tasks, setTasks]             = useState([]);
  const [maintenance, setMaintenance] = useState([]);
  const [staff, setStaff]             = useState([]);
  const [complaints, setComplaints]   = useState([]);
  const [pendingOtps, setPendingOtps] = useState([]);
  const [otpInputs, setOtpInputs]     = useState({});
  const [announcements, setAnnouncements] = useState([]);
  const [facilityBookings, setFacilityBookings] = useState([]);
  const [loading, setLoading]         = useState(false);

  const [taskModalVisible, setTaskModalVisible]         = useState(false);
  const [sosModalVisible, setSosModalVisible]           = useState(false);
  const [facilityModalVisible, setFacilityModalVisible] = useState(false);

  const [rtTitle, setRtTitle]       = useState('');
  const [rtDesc, setRtDesc]         = useState('');
  const [rtTo, setRtTo]             = useState('maid');
  const [rtName, setRtName]         = useState('');
  const [rtPriority, setRtPriority] = useState('medium');
  const [rtDue, setRtDue]           = useState('');

  const [bmName, setBmName]         = useState('');
  const [bmPhone, setBmPhone]       = useState('');
  const [bmScheduled, setBmScheduled] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [datePickerMode, setDatePickerMode] = useState('date');

  const [cSubject, setCSubject]     = useState('');
  const [cDesc, setCDesc]           = useState('');
  const [cCategory, setCCategory]   = useState('Noise Complaint');
  const [sosMessage, setSosMessage] = useState('');

  const [selectedFacility, setSelectedFacility] = useState(null);
  const [fbDate, setFbDate]         = useState(new Date());
  const [fbTimeSlot, setFbTimeSlot] = useState('09:00 - 12:00');
  const [fbPurpose, setFbPurpose]   = useState('');
  const [fbGuests, setFbGuests]     = useState('');
  const [fbPhone, setFbPhone]       = useState('');
  const [showFbDatePicker, setShowFbDatePicker] = useState(false);

  const FACILITIES = [
    { name: 'Clubhouse', type: 'club', icon: '🏠' },
    { name: 'Park & Garden', type: 'outdoor', icon: '🌳' },
    { name: 'Swimming Pool', type: 'sports', icon: '🏊' },
    { name: 'Gym', type: 'sports', icon: '💪' },
    { name: 'Banquet Hall', type: 'event', icon: '🎊' },
    { name: 'Terrace', type: 'outdoor', icon: '🌆' },
    { name: 'Conference Room', type: 'meeting', icon: '💼' },
    { name: 'Tennis Court', type: 'sports', icon: '🎾' },
  ];

  const TIME_SLOTS = [
    '06:00 - 09:00', '09:00 - 12:00', '12:00 - 15:00',
    '15:00 - 18:00', '18:00 - 21:00', '21:00 - 23:00', 'Full Day'
  ];

  const CATEGORY_STYLE = {
    festival:    { bg: '#fef3c7', color: '#92400e' },
    celebration: { bg: '#fce7f3', color: '#9d174d' },
    wishes:      { bg: '#ede9fe', color: '#5b21b6' },
    event:       { bg: '#dbeafe', color: '#1e40af' },
    holiday:     { bg: '#d1fae5', color: '#065f46' },
    general:     { bg: '#e5e7eb', color: '#374151' },
    maintenance: { bg: '#ffedd5', color: '#c2410c' },
    emergency:   { bg: '#fee2e2', color: '#991b1b' },
  };

  useEffect(() => {
    (async () => {
      try {
        const name  = await AsyncStorage.getItem('@mygate_name');
        const email = await AsyncStorage.getItem('@mygate_email');
        const apt   = await AsyncStorage.getItem('@mygate_apartment');
        setUser(prev => ({
          ...prev,
          name:      name  || prev.name,
          email:     email || prev.email,
          apartment: apt   || prev.apartment,
        }));
      } catch (_) {}
    })();
    loadAllData();
    const poll = setInterval(() => { loadPendingOtps(); loadAnnouncements(); }, 20000);
    return () => clearInterval(poll);
  }, []);

  const validatePhone = (phone) => /^[6-9]\d{9}$/.test(phone.trim());

  const loadAllData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadVisitors(), loadTasks(), loadMaintenance(),
        loadStaff(), loadPendingOtps(), loadAnnouncements(),
        loadComplaints(), loadFacilityBookingsData()
      ]);
    } catch (_) {}
    setLoading(false);
  };

  const loadVisitors = async () => {
    const d = await apiFetch('/api/v2/admin/visitors');
    setVisitors(d?.data?.visitors || d?.data || []);
  };

  const loadTasks = async () => {
    const d = await apiFetch('/api/v2/tasks');
    setTasks(d?.data?.tasks || d?.data || []);
  };

  const loadMaintenance = async () => {
    const d = await apiFetch('/api/v2/maintenance');
    setMaintenance(d?.data?.alerts || d?.data || []);
  };

  const loadStaff = async () => {
    const d = await apiFetch('/api/v2/admin/staff');
    setStaff(d?.data?.staff || d?.data || []);
  };

  const loadPendingOtps = async () => {
    const d = await apiFetch('/api/v2/tasks/pending-otps?recipient=resident');
    setPendingOtps(d?.data?.pendingOtps || []);
  };

  const loadAnnouncements = async () => {
    const d = await apiFetch('/api/v2/announcements');
    setAnnouncements(d?.data?.announcements || []);
  };

  const loadComplaints = async () => {
    const d = await apiFetch('/api/v2/complaints');
    setComplaints(d?.data?.complaints || []);
  };

  const loadFacilityBookingsData = async () => {
    const apt = user.apartment;
    const url = apt ? `/api/v2/facilities/by-flat/${encodeURIComponent(apt)}` : '/api/v2/facilities';
    const d = await apiFetch(url);
    setFacilityBookings(d?.data?.bookings || []);
  };

  const handleVisitorStatus = async (id, status) => {
    await apiFetch(`/api/v2/admin/visitors/${id}/status`, {
      method: 'PUT', body: JSON.stringify({ status })
    });
    setVisitors(prev => prev.map(v => v.id === id ? { ...v, status } : v));
    Alert.alert('Done', `Visitor ${status}.`);
  };

  const handleAssignTask = async () => {
    if (!rtTitle.trim()) { Alert.alert('Required', 'Task title is required.'); return; }
    const body = { title: rtTitle, description: rtDesc, assignTo: rtTo, assignedName: rtName,
      priority: rtPriority, dueDate: rtDue, location: user.apartment, createdBy: 'resident', otpRecipient: 'resident' };
    await apiFetch('/api/v2/tasks', { method: 'POST', body: JSON.stringify(body) });
    setRtTitle(''); setRtDesc(''); setRtName(''); setRtDue('');
    setTaskModalVisible(false);
    await loadTasks();
    Alert.alert('Done', 'Task assigned.');
  };

  const handleBookMaid = async () => {
    if (!bmName.trim()) { Alert.alert('Required', 'Maid name is required.'); return; }
    if (bmPhone && !validatePhone(bmPhone)) {
      Alert.alert('Invalid Phone', 'Enter a valid 10-digit Indian mobile number starting with 6-9.');
      return;
    }
    const flat = user.apartment || '';
    const scheduledStr = bmScheduled.toISOString().slice(0, 16);
    const bookingBody = { name: bmName, phone: bmPhone, flat, apartment: flat, scheduledAt: scheduledStr };
    await apiFetch('/api/v2/resident/hire-maid', { method: 'POST', body: JSON.stringify(bookingBody) });
    const taskBody = {
      title: `Maid visit — Flat ${flat}`,
      description: `Booked by ${user.name || 'Resident'}${bmPhone ? ' | Ph: ' + bmPhone : ''}`,
      assignTo: 'maid', assignedName: bmName, priority: 'medium',
      dueDate: scheduledStr.slice(0, 10), location: flat,
      createdBy: 'resident', otpRecipient: 'resident'
    };
    await apiFetch('/api/v2/tasks', { method: 'POST', body: JSON.stringify(taskBody) });
    setBmName(''); setBmPhone(''); setBmScheduled(new Date());
    await loadStaff();
    Alert.alert('Confirmed', 'Maid booked. OTP will be sent to you when the task is complete.');
  };

  const handleFacilityBook = async () => {
    if (!selectedFacility) return;
    if (!fbPurpose.trim()) { Alert.alert('Required', 'Please enter the purpose / event name.'); return; }
    if (fbPhone && !validatePhone(fbPhone)) {
      Alert.alert('Invalid Phone', 'Enter a valid 10-digit Indian mobile number.');
      return;
    }
    const body = {
      facilityName: selectedFacility.name,
      facilityType: selectedFacility.type,
      bookingDate: fbDate.toISOString().slice(0, 10),
      timeSlot: fbTimeSlot,
      purpose: fbPurpose,
      expectedGuests: fbGuests ? parseInt(fbGuests) : 0,
      residentName: user.name || user.email || 'Resident',
      residentFlat: user.apartment || '',
      residentPhone: fbPhone
    };
    const res = await apiFetch('/api/v2/facilities', { method: 'POST', body: JSON.stringify(body) });
    if (res?.success) {
      setFacilityModalVisible(false);
      setFbPurpose(''); setFbGuests(''); setFbPhone(''); setFbDate(new Date());
      await loadFacilityBookingsData();
      Alert.alert('Request Sent', 'Facility booking request sent to Admin for approval.');
    } else {
      Alert.alert('Failed', res?.error || 'Could not submit booking.');
    }
  };

  const verifyOtp = async (taskId) => {
    const otp = (otpInputs[taskId] || '').trim();
    if (!otp || otp.length !== 6) { Alert.alert('Required', 'Enter the 6-digit OTP.'); return; }
    const res = await apiFetch(`/api/v2/tasks/${taskId}/verify-otp`, {
      method: 'POST', body: JSON.stringify({ otp })
    });
    if (res?.success) {
      Alert.alert('Verified', 'Task marked as completed.');
      setOtpInputs(prev => { const n = { ...prev }; delete n[taskId]; return n; });
      await loadPendingOtps(); await loadTasks();
    } else {
      Alert.alert('Error', res?.error || 'Invalid OTP.');
    }
  };

  const handleSendSOS = async () => {
    await apiFetch('/api/v2/sos', {
      method: 'POST',
      body: JSON.stringify({ resident: user.name, flat: user.apartment, message: sosMessage || 'Emergency! Please send help.' })
    });
    setSosModalVisible(false); setSosMessage('');
    Alert.alert('SOS Sent', 'Emergency alert sent to Admin and all Guards.');
  };

  const handleFileComplaint = async () => {
    if (!cSubject.trim()) { Alert.alert('Required', 'Subject is required.'); return; }
    const res = await apiFetch('/api/v2/complaints', {
      method: 'POST',
      body: JSON.stringify({ subject: cSubject, description: cDesc, category: cCategory,
        flat: user.apartment, residentName: user.name || user.email || 'Resident' })
    });
    if (res?.success) {
      setCSubject(''); setCDesc('');
      await loadComplaints();
      Alert.alert('Filed', 'Complaint submitted.');
    } else {
      Alert.alert('Error', res?.error || 'Failed to submit.');
    }
  };

  const handleLogout = async () => {
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Logout', style: 'destructive', onPress: async () => {
        await AsyncStorage.multiRemove(['@mygate_token', '@mygate_role', '@mygate_name', '@mygate_email', '@mygate_apartment']);
        if (onLogout) onLogout();
      }}
    ]);
  };

  const onDateChange = (event, date) => {
    setShowDatePicker(false);
    if (date) {
      if (datePickerMode === 'date') {
        const merged = new Date(bmScheduled);
        merged.setFullYear(date.getFullYear(), date.getMonth(), date.getDate());
        setBmScheduled(merged);
        setDatePickerMode('time');
        setShowDatePicker(true);
      } else {
        const merged = new Date(bmScheduled);
        merged.setHours(date.getHours(), date.getMinutes());
        setBmScheduled(merged);
        setDatePickerMode('date');
      }
    }
  };

  const formatDateTime = (d) => {
    const pad = n => String(n).padStart(2,'0');
    return `${pad(d.getDate())}-${pad(d.getMonth()+1)}-${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };

  const formatDate = (d) => {
    const pad = n => String(n).padStart(2,'0');
    return `${pad(d.getDate())}-${pad(d.getMonth()+1)}-${d.getFullYear()}`;
  };

  const pendingVisitors = visitors.filter(v => v.status === 'pending');
  const festivAnnounces = announcements.filter(a => ['festival','celebration','wishes','holiday','event'].includes(a.category));

  const renderHomeTab = () => (
    <View>
      {pendingOtps.length > 0 && (
        <View style={styles.otpBox}>
          <Text style={styles.otpBoxTitle}>🔑 OTP Verification Required ({pendingOtps.length})</Text>
          {pendingOtps.map(o => (
            <View key={o.taskId} style={styles.otpRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.otpLabel}>{o.title}</Text>
                <Text style={styles.otpSub}>Staff: {o.assignedName || '—'}</Text>
              </View>
              <TextInput
                style={styles.otpInput}
                placeholder="OTP"
                keyboardType="number-pad"
                maxLength={6}
                value={otpInputs[o.taskId] || ''}
                onChangeText={val => setOtpInputs(prev => ({ ...prev, [o.taskId]: val }))}
              />
              <TouchableOpacity style={styles.otpBtn} onPress={() => verifyOtp(o.taskId)}>
                <Text style={styles.otpBtnText}>Verify</Text>
              </TouchableOpacity>
            </View>
          ))}
        </View>
      )}

      {festivAnnounces.length > 0 && (
        <TouchableOpacity style={styles.festivalBanner} onPress={() => setActiveTab('announcements')}>
          <Text style={{ fontSize: 20 }}>{festivAnnounces[0].emoji || '🎉'}</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.festivalTitle}>{festivAnnounces[0].title}</Text>
            {festivAnnounces[0].message ? <Text style={styles.festivalMsg} numberOfLines={1}>{festivAnnounces[0].message}</Text> : null}
          </View>
          <Text style={{ color: '#b45309', fontSize: 12 }}>See all →</Text>
        </TouchableOpacity>
      )}

      {maintenance.length > 0 && maintenance.slice(0, 2).map(a => (
        <View key={a.id} style={styles.alertBanner}>
          <Text style={{ fontSize: 18 }}>🔨</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.alertTitle}>{a.title}{a.area ? ` — ${a.area}` : ''}</Text>
            <Text style={styles.alertBody}>{a.description || ''}</Text>
          </View>
        </View>
      ))}

      <View style={styles.statsRow}>
        <View style={styles.statCard}>
          <Text style={styles.statIcon}>👥</Text>
          <Text style={styles.statNum}>{visitors.length}</Text>
          <Text style={styles.statLbl}>Visitors</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statIcon}>✅</Text>
          <Text style={styles.statNum}>{tasks.filter(t => t.status !== 'done').length}</Text>
          <Text style={styles.statLbl}>Active Tasks</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statIcon}>🔧</Text>
          <Text style={styles.statNum}>{staff.filter(s => !s.exit_time).length}</Text>
          <Text style={styles.statLbl}>Staff Inside</Text>
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>🆘 Emergency SOS</Text>
        <Text style={styles.sosDesc}>Tap below to instantly alert Admin and all Guards.</Text>
        <TouchableOpacity style={styles.sosButton} onPress={() => setSosModalVisible(true)}>
          <Text style={styles.sosBtnText}>🆘 SEND SOS EMERGENCY ALERT</Text>
        </TouchableOpacity>
      </View>

      {pendingVisitors.length > 0 && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>👥 Pending Visitor Approvals</Text>
          {pendingVisitors.map(v => (
            <View key={v.id} style={styles.approvalItem}>
              <View style={{ flex: 1 }}>
                <Text style={styles.rowBold}>{v.visitor_name || v.name}</Text>
                <Text style={styles.rowSub}>{v.reason_of_visit} • {v.registered_at}</Text>
              </View>
              <View style={styles.actionRow}>
                <TouchableOpacity style={[styles.inlineBtn, styles.btnSuccess]} onPress={() => handleVisitorStatus(v.id, 'approved')}>
                  <Text style={styles.btnTxt}>Approve</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.inlineBtn, styles.btnDanger]} onPress={() => handleVisitorStatus(v.id, 'denied')}>
                  <Text style={styles.btnTxt}>Deny</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>
      )}
    </View>
  );

  const renderVisitorsTab = () => (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>👥 Visitor Log</Text>
      {visitors.length === 0 ? <Text style={styles.emptyText}>No visitors logged.</Text> : visitors.map(v => (
        <View key={v.id} style={styles.listRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.rowBold}>{v.visitor_name || v.name}</Text>
            <Text style={styles.rowSub}>{v.reason_of_visit} • {v.registered_at}</Text>
          </View>
          <View style={[styles.badge, { backgroundColor: v.status === 'approved' ? '#dcfce7' : v.status === 'denied' ? '#fee2e2' : '#fef3c7' }]}>
            <Text style={[styles.badgeTxt, { color: v.status === 'approved' ? '#166534' : v.status === 'denied' ? '#991b1b' : '#92400e' }]}>{v.status?.toUpperCase()}</Text>
          </View>
        </View>
      ))}
    </View>
  );

  const renderTasksTab = () => (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <Text style={styles.cardTitle}>✅ Assign Tasks</Text>
        <TouchableOpacity style={styles.btnPrimary} onPress={() => setTaskModalVisible(true)}>
          <Text style={styles.btnTxt}>+ Assign</Text>
        </TouchableOpacity>
      </View>
      {pendingOtps.length > 0 && (
        <View style={styles.otpBox}>
          <Text style={styles.otpBoxTitle}>🔑 OTP Required ({pendingOtps.length})</Text>
          {pendingOtps.map(o => (
            <View key={o.taskId} style={styles.otpRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.otpLabel}>{o.title}</Text>
              </View>
              <TextInput style={styles.otpInput} placeholder="OTP" keyboardType="number-pad" maxLength={6}
                value={otpInputs[o.taskId] || ''} onChangeText={val => setOtpInputs(p => ({ ...p, [o.taskId]: val }))} />
              <TouchableOpacity style={styles.otpBtn} onPress={() => verifyOtp(o.taskId)}>
                <Text style={styles.otpBtnText}>Verify</Text>
              </TouchableOpacity>
            </View>
          ))}
        </View>
      )}
      {tasks.length === 0 ? <Text style={styles.emptyText}>No tasks assigned yet.</Text> : tasks.map(t => (
        <View key={t.id} style={[styles.taskItem, { borderLeftColor: t.status === 'done' ? '#10b981' : t.status === 'otp_pending' ? '#f59e0b' : '#9ca3af' }]}>
          <View style={{ flex: 1 }}>
            <Text style={styles.rowBold}>{t.title}</Text>
            <Text style={styles.rowSub}>→ {t.assignedName} • Due: {t.dueDate || '—'}</Text>
          </View>
          <View style={[styles.badge, { backgroundColor: t.status === 'done' ? '#d1fae5' : t.status === 'otp_pending' ? '#fef3c7' : '#f3f4f6' }]}>
            <Text style={[styles.badgeTxt, { color: t.status === 'done' ? '#065f46' : t.status === 'otp_pending' ? '#92400e' : '#374151' }]}>{t.status}</Text>
          </View>
        </View>
      ))}
    </View>
  );

  const renderMaidTab = () => (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>🧹 Book a Maid</Text>
      <Text style={styles.fieldLabel}>Maid Name</Text>
      <TextInput style={styles.input} placeholder="e.g. Sunita Devi" value={bmName} onChangeText={setBmName} />

      <Text style={styles.fieldLabel}>Phone Number</Text>
      <TextInput style={styles.input} keyboardType="phone-pad" placeholder="10-digit mobile number" maxLength={10}
        value={bmPhone} onChangeText={t => setBmPhone(t.replace(/\D/g, ''))} />

      <Text style={styles.fieldLabel}>Schedule Date & Time</Text>
      <TouchableOpacity style={styles.datePickerBtn} onPress={() => { setDatePickerMode('date'); setShowDatePicker(true); }}>
        <Text style={styles.datePickerTxt}>📅 {formatDateTime(bmScheduled)}</Text>
      </TouchableOpacity>
      {showDatePicker && (
        <DateTimePicker value={bmScheduled} mode={datePickerMode} display={Platform.OS === 'ios' ? 'spinner' : 'default'}
          minimumDate={new Date()} onChange={onDateChange} />
      )}

      <TouchableOpacity style={[styles.btnPrimaryLong, { marginTop: 12 }]} onPress={handleBookMaid}>
        <Text style={styles.btnTxtLong}>🧹 Confirm Booking</Text>
      </TouchableOpacity>

      {staff.filter(s => (s.type || '').toLowerCase() === 'maid').length > 0 && (
        <View style={{ marginTop: 16 }}>
          <Text style={styles.subHeading}>📋 Your Maid Bookings</Text>
          {staff.filter(s => (s.type || '').toLowerCase() === 'maid').map(s => (
            <View key={s.id} style={styles.listRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.rowBold}>🧹 {s.name}</Text>
                <Text style={styles.rowSub}>{s.phone || '—'} • {s.entry_time || s.scheduled_at || '—'}</Text>
              </View>
              <View style={[styles.badge, { backgroundColor: s.exit_time ? '#f3f4f6' : '#dcfce7' }]}>
                <Text style={[styles.badgeTxt, { color: s.exit_time ? '#374151' : '#166534' }]}>{s.exit_time ? 'Done' : 'Booked'}</Text>
              </View>
            </View>
          ))}
        </View>
      )}
    </View>
  );

  const renderFacilityTab = () => (
    <View>
      <View style={styles.card}>
        <Text style={styles.cardTitle}>🏛️ Book a Facility</Text>
        <Text style={styles.rowSub}>Select a facility. Bookings go to Admin for approval.</Text>
        <View style={styles.facilityGrid}>
          {FACILITIES.map(f => (
            <TouchableOpacity key={f.name} style={styles.facilityCard} onPress={() => { setSelectedFacility(f); setFacilityModalVisible(true); }}>
              <Text style={styles.facilityIcon}>{f.icon}</Text>
              <Text style={styles.facilityName}>{f.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {facilityBookings.length > 0 && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>📋 My Booking Requests</Text>
          {facilityBookings.map(b => (
            <View key={b.id} style={styles.listRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.rowBold}>{b.facilityName}</Text>
                <Text style={styles.rowSub}>{b.bookingDate} • {b.timeSlot} • {b.purpose}</Text>
                {b.adminNote ? <Text style={{ fontSize: 11, color: '#6366f1', marginTop: 2 }}>Note: {b.adminNote}</Text> : null}
              </View>
              <View style={[styles.badge, { backgroundColor: b.status === 'approved' ? '#dcfce7' : b.status === 'rejected' ? '#fee2e2' : '#fef3c7' }]}>
                <Text style={[styles.badgeTxt, { color: b.status === 'approved' ? '#166534' : b.status === 'rejected' ? '#991b1b' : '#92400e' }]}>{b.status}</Text>
              </View>
            </View>
          ))}
        </View>
      )}
    </View>
  );

  const renderAnnouncementsTab = () => (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>📣 Announcements</Text>
      {announcements.length === 0 ? <Text style={styles.emptyText}>No announcements yet.</Text> : announcements.map(a => {
        const cs = CATEGORY_STYLE[a.category] || CATEGORY_STYLE.general;
        return (
          <View key={a.id} style={[styles.announceCard, a.pinned && { borderColor: '#6366f1', backgroundColor: '#f5f3ff' }]}>
            <Text style={{ fontSize: 24, marginRight: 10 }}>{a.emoji || '📢'}</Text>
            <View style={{ flex: 1 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 4 }}>
                <Text style={styles.announceTitle}>{a.title}</Text>
                {a.pinned && <View style={styles.pinnedBadge}><Text style={{ color: '#fff', fontSize: 9, fontWeight: '700' }}>PINNED</Text></View>}
                <View style={[styles.catBadge, { backgroundColor: cs.bg }]}>
                  <Text style={[styles.catBadgeTxt, { color: cs.color }]}>{(a.category || 'general').toUpperCase()}</Text>
                </View>
              </View>
              {a.message ? <Text style={styles.announceMsg}>{a.message}</Text> : null}
              <Text style={styles.announceMeta}>By {a.postedBy || 'Admin'} • {a.createdAt || ''}</Text>
            </View>
          </View>
        );
      })}
    </View>
  );

  const renderMaintenanceTab = () => (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>🔨 Maintenance Alerts</Text>
      {maintenance.length === 0 ? <Text style={styles.emptyText}>No active maintenance alerts ✅</Text> : maintenance.map(a => (
        <View key={a.id} style={styles.alertBanner}>
          <Text style={{ fontSize: 18 }}>🔨</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.alertTitle}>{a.title}{a.area ? ` — ${a.area}` : ''}</Text>
            <Text style={styles.alertBody}>{a.description || ''}</Text>
            <Text style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>{a.createdAt || ''} • Severity: {a.severity || 'low'}</Text>
          </View>
        </View>
      ))}
    </View>
  );

  const renderBillsTab = () => (
    <View>
      <View style={styles.statsRow}>
        <View style={[styles.statCard, { borderLeftColor: '#ef4444', borderLeftWidth: 3 }]}>
          <Text style={styles.statNum}>₹2,800</Text><Text style={styles.statLbl}>Maintenance</Text>
        </View>
        <View style={[styles.statCard, { borderLeftColor: '#f97316', borderLeftWidth: 3 }]}>
          <Text style={styles.statNum}>₹1,450</Text><Text style={styles.statLbl}>Electricity</Text>
        </View>
        <View style={[styles.statCard, { borderLeftColor: '#3b82f6', borderLeftWidth: 3 }]}>
          <Text style={styles.statNum}>₹380</Text><Text style={styles.statLbl}>Water</Text>
        </View>
      </View>
      <View style={styles.card}>
        <Text style={styles.cardTitle}>💰 Bills & Payments</Text>
        {[
          { label: 'Monthly Maintenance', amount: '₹2,800', due: '01 Jun 2026', status: 'Pending', color: '#dc2626' },
          { label: 'Electricity Bill', amount: '₹1,450', due: '15 May 2026', status: 'Due Soon', color: '#d97706' },
          { label: 'Water Charges (Mar)', amount: '₹380', due: 'Paid', status: 'Paid', color: '#16a34a' },
        ].map((b, i) => (
          <View key={i} style={styles.listRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowBold}>{b.label}</Text>
              <Text style={styles.rowSub}>Due: {b.due}</Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={{ fontWeight: '700', color: '#111' }}>{b.amount}</Text>
              <Text style={{ fontSize: 11, color: b.color, fontWeight: '600' }}>{b.status}</Text>
            </View>
          </View>
        ))}
      </View>
    </View>
  );

  const renderComplaintsTab = () => (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>📝 File a Complaint</Text>
      <Text style={styles.fieldLabel}>Subject</Text>
      <TextInput style={styles.input} placeholder="e.g. Noisy neighbours" value={cSubject} onChangeText={setCSubject} />
      <Text style={styles.fieldLabel}>Description</Text>
      <TextInput style={[styles.input, styles.textArea]} multiline numberOfLines={3}
        placeholder="Describe your complaint..." value={cDesc} onChangeText={setCDesc} />
      <TouchableOpacity style={styles.btnPrimaryLong} onPress={handleFileComplaint}>
        <Text style={styles.btnTxtLong}>Submit Complaint</Text>
      </TouchableOpacity>
      {complaints.length > 0 && (
        <View style={{ marginTop: 16 }}>
          <Text style={styles.subHeading}>Past Complaints</Text>
          {complaints.map(c => (
            <View key={c.id} style={[styles.listRow, { alignItems: 'flex-start' }]}>
              <View style={{ flex: 1 }}>
                <Text style={styles.rowBold}>{c.subject}</Text>
                <Text style={styles.rowSub}>{c.description}</Text>
                <Text style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>{c.createdAt}</Text>
              </View>
              <View style={[styles.badge, { backgroundColor: c.status === 'resolved' ? '#dcfce7' : '#fef3c7' }]}>
                <Text style={[styles.badgeTxt, { color: c.status === 'resolved' ? '#166534' : '#92400e' }]}>{c.status === 'resolved' ? 'Resolved' : 'Open'}</Text>
              </View>
            </View>
          ))}
        </View>
      )}
    </View>
  );

  const TABS = [
    { id: 'home', icon: '🏠', label: 'Home' },
    { id: 'visitors', icon: '👥', label: 'Visitors' },
    { id: 'tasks', icon: '✅', label: 'Tasks' },
    { id: 'maid', icon: '🧹', label: 'Maid' },
    { id: 'facility', icon: '🏛️', label: 'Facility' },
    { id: 'announces', icon: '📣', label: 'Notice' },
    { id: 'maintenance', icon: '🔨', label: 'Alerts' },
    { id: 'bills', icon: '💰', label: 'Bills' },
    { id: 'complaints', icon: '📝', label: 'Issues' },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.topbar}>
        <View>
          <Text style={styles.topbarName}>MyGate</Text>
          <Text style={styles.topbarSub}>Flat {user.apartment || '—'} • Resident</Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          {announcements.length > 0 && (
            <View style={styles.notifDot}><Text style={styles.notifTxt}>{announcements.length}</Text></View>
          )}
          <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
            <Text style={styles.logoutTxt}>🚪 Logout</Text>
          </TouchableOpacity>
          <View style={styles.avatar}><Text style={styles.avatarTxt}>{(user.name || 'R').charAt(0)}</Text></View>
        </View>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#1d4ed8" style={{ flex: 1 }} />
      ) : (
        <ScrollView style={styles.body} showsVerticalScrollIndicator={false}>
          {activeTab === 'home'         && renderHomeTab()}
          {activeTab === 'visitors'     && renderVisitorsTab()}
          {activeTab === 'tasks'        && renderTasksTab()}
          {activeTab === 'maid'         && renderMaidTab()}
          {activeTab === 'facility'     && renderFacilityTab()}
          {activeTab === 'announces'    && renderAnnouncementsTab()}
          {activeTab === 'maintenance'  && renderMaintenanceTab()}
          {activeTab === 'bills'        && renderBillsTab()}
          {activeTab === 'complaints'   && renderComplaintsTab()}
          <View style={{ height: 40 }} />
        </ScrollView>
      )}

      <View style={styles.tabBar}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 8 }}>
          {TABS.map(t => (
            <TouchableOpacity key={t.id} style={[styles.tabItem, activeTab === t.id && styles.tabItemActive]}
              onPress={() => setActiveTab(t.id)}>
              <Text style={styles.tabIcon}>{t.icon}</Text>
              <Text style={[styles.tabLabel, activeTab === t.id && { color: '#1d4ed8' }]}>{t.label}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <Modal visible={taskModalVisible} animationType="slide" transparent>
        <View style={styles.overlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Assign Task</Text>
            <TextInput style={styles.input} placeholder="Task title" value={rtTitle} onChangeText={setRtTitle} />
            <TextInput style={styles.input} placeholder="Description" value={rtDesc} onChangeText={setRtDesc} />
            <TextInput style={styles.input} placeholder="Person name" value={rtName} onChangeText={setRtName} />
            <TextInput style={styles.input} placeholder="Due date (YYYY-MM-DD)" value={rtDue} onChangeText={setRtDue} />
            <View style={styles.actionRow}>
              <TouchableOpacity style={[styles.modalBtn, { backgroundColor: '#6b7280' }]} onPress={() => setTaskModalVisible(false)}>
                <Text style={styles.btnTxt}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.modalBtn, { backgroundColor: '#1d4ed8' }]} onPress={handleAssignTask}>
                <Text style={styles.btnTxt}>Assign</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={facilityModalVisible} animationType="slide" transparent>
        <View style={styles.overlay}>
          <ScrollView>
            <View style={styles.modalCard}>
              <Text style={styles.modalTitle}>{selectedFacility ? selectedFacility.icon + ' Book ' + selectedFacility.name : 'Book Facility'}</Text>

              <Text style={styles.fieldLabel}>Date</Text>
              <TouchableOpacity style={styles.datePickerBtn} onPress={() => setShowFbDatePicker(true)}>
                <Text style={styles.datePickerTxt}>📅 {formatDate(fbDate)}</Text>
              </TouchableOpacity>
              {showFbDatePicker && (
                <DateTimePicker value={fbDate} mode="date" display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                  minimumDate={new Date()} onChange={(e, d) => { setShowFbDatePicker(false); if (d) setFbDate(d); }} />
              )}

              <Text style={styles.fieldLabel}>Time Slot</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10 }}>
                {TIME_SLOTS.map(slot => (
                  <TouchableOpacity key={slot} style={[styles.slotChip, fbTimeSlot === slot && styles.slotChipActive]}
                    onPress={() => setFbTimeSlot(slot)}>
                    <Text style={[styles.slotTxt, fbTimeSlot === slot && { color: '#fff' }]}>{slot}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              <Text style={styles.fieldLabel}>Purpose / Event Name</Text>
              <TextInput style={styles.input} placeholder="e.g. Birthday Party, Pooja" value={fbPurpose} onChangeText={setFbPurpose} />

              <Text style={styles.fieldLabel}>Expected Guests</Text>
              <TextInput style={styles.input} keyboardType="number-pad" placeholder="e.g. 20" value={fbGuests} onChangeText={setFbGuests} />

              <Text style={styles.fieldLabel}>Your Phone</Text>
              <TextInput style={styles.input} keyboardType="phone-pad" placeholder="10-digit number" maxLength={10}
                value={fbPhone} onChangeText={t => setFbPhone(t.replace(/\D/g, ''))} />

              <View style={styles.actionRow}>
                <TouchableOpacity style={[styles.modalBtn, { backgroundColor: '#6b7280' }]} onPress={() => setFacilityModalVisible(false)}>
                  <Text style={styles.btnTxt}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.modalBtn, { backgroundColor: '#1d4ed8' }]} onPress={handleFacilityBook}>
                  <Text style={styles.btnTxt}>Send Request</Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </View>
      </Modal>

      <Modal visible={sosModalVisible} animationType="fade" transparent>
        <View style={styles.overlay}>
          <View style={[styles.modalCard, { alignItems: 'center' }]}>
            <Text style={{ fontSize: 44 }}>🆘</Text>
            <Text style={[styles.modalTitle, { textAlign: 'center' }]}>Confirm Emergency SOS</Text>
            <Text style={[styles.rowSub, { textAlign: 'center', marginBottom: 12 }]}>
              This instantly alerts Admin and all Guards. Use only in real emergencies.
            </Text>
            <TextInput style={[styles.input, { width: '100%' }]} placeholder="Optional message..." value={sosMessage} onChangeText={setSosMessage} />
            <View style={styles.actionRow}>
              <TouchableOpacity style={[styles.modalBtn, { backgroundColor: '#9ca3af' }]} onPress={() => setSosModalVisible(false)}>
                <Text style={styles.btnTxt}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.modalBtn, { backgroundColor: '#dc2626' }]} onPress={handleSendSOS}>
                <Text style={styles.btnTxt}>🚨 Send SOS</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container:       { flex: 1, backgroundColor: '#f3f4f6' },
  topbar:          { height: 70, backgroundColor: '#fff', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: '#e5e7eb', paddingTop: 8 },
  topbarName:      { fontSize: 18, fontWeight: '800', color: '#111' },
  topbarSub:       { fontSize: 11, color: '#6b7280' },
  avatar:          { width: 36, height: 36, borderRadius: 18, backgroundColor: '#4f46e5', justifyContent: 'center', alignItems: 'center' },
  avatarTxt:       { color: '#fff', fontWeight: '700', fontSize: 15 },
  logoutBtn:       { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 6, backgroundColor: '#fee2e2' },
  logoutTxt:       { fontSize: 12, fontWeight: '600', color: '#dc2626' },
  notifDot:        { backgroundColor: '#ef4444', borderRadius: 10, paddingHorizontal: 6, paddingVertical: 2 },
  notifTxt:        { color: '#fff', fontSize: 11, fontWeight: '700' },
  body:            { flex: 1, padding: 12 },

  card:            { backgroundColor: '#fff', borderRadius: 12, padding: 14, marginBottom: 14, borderWidth: 1, borderColor: '#e5e7eb' },
  cardHeader:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  cardTitle:       { fontSize: 14, fontWeight: '700', color: '#1f2937', marginBottom: 10 },
  subHeading:      { fontSize: 13, fontWeight: '700', color: '#374151', marginBottom: 8 },
  emptyText:       { color: '#9ca3af', fontSize: 13, textAlign: 'center', paddingVertical: 16 },

  statsRow:        { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 14 },
  statCard:        { flex: 1, backgroundColor: '#fff', borderRadius: 10, padding: 12, marginHorizontal: 3, alignItems: 'center', borderWidth: 1, borderColor: '#e5e7eb' },
  statIcon:        { fontSize: 18, marginBottom: 2 },
  statNum:         { fontSize: 18, fontWeight: '800', color: '#111' },
  statLbl:         { fontSize: 10, color: '#6b7280', marginTop: 1 },

  sosButton:       { backgroundColor: '#dc2626', paddingVertical: 12, borderRadius: 8, alignItems: 'center', marginTop: 8 },
  sosBtnText:      { color: '#fff', fontWeight: '700', fontSize: 13 },
  sosDesc:         { fontSize: 12, color: '#b91c1c', marginBottom: 4, lineHeight: 16 },

  otpBox:          { backgroundColor: '#fffbeb', borderColor: '#fcd34d', borderWidth: 1.5, borderRadius: 12, padding: 12, marginBottom: 14 },
  otpBoxTitle:     { fontSize: 13, fontWeight: '700', color: '#92400e', marginBottom: 8 },
  otpRow:          { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6, flexWrap: 'wrap' },
  otpLabel:        { fontSize: 12, fontWeight: '600', color: '#78350f' },
  otpSub:          { fontSize: 10, color: '#92400e' },
  otpInput:        { borderWidth: 1.5, borderColor: '#fcd34d', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 5, fontSize: 14, fontWeight: '700', letterSpacing: 2, width: 90, textAlign: 'center', backgroundColor: '#fff' },
  otpBtn:          { backgroundColor: '#f59e0b', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 6 },
  otpBtnText:      { color: '#fff', fontWeight: '700', fontSize: 11 },

  alertBanner:     { flexDirection: 'row', gap: 10, backgroundColor: '#fffbeb', borderColor: '#fcd34d', borderWidth: 1, borderRadius: 10, padding: 10, marginBottom: 8, alignItems: 'flex-start' },
  alertTitle:      { fontSize: 13, fontWeight: '700', color: '#92400e' },
  alertBody:       { fontSize: 11, color: '#78350f', marginTop: 2 },

  festivalBanner:  { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: '#fef3c7', borderColor: '#f59e0b', borderWidth: 1.5, borderRadius: 10, padding: 10, marginBottom: 12 },
  festivalTitle:   { fontSize: 13, fontWeight: '700', color: '#92400e' },
  festivalMsg:     { fontSize: 11, color: '#b45309' },

  approvalItem:    { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#f3f4f6' },
  actionRow:       { flexDirection: 'row', gap: 6 },
  listRow:         { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#f3f4f6' },
  rowBold:         { fontSize: 13, fontWeight: '600', color: '#1f2937' },
  rowSub:          { fontSize: 11, color: '#6b7280', marginTop: 2 },

  badge:           { paddingHorizontal: 7, paddingVertical: 3, borderRadius: 4 },
  badgeTxt:        { fontSize: 9, fontWeight: '700' },

  taskItem:        { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#f3f4f6', borderLeftWidth: 3, paddingLeft: 10, marginBottom: 2 },

  fieldLabel:      { fontSize: 12, fontWeight: '600', color: '#4b5563', marginBottom: 4, marginTop: 6 },
  input:           { backgroundColor: '#f9fafb', borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8, fontSize: 13, marginBottom: 8, color: '#111' },
  textArea:        { height: 70, textAlignVertical: 'top' },
  datePickerBtn:   { backgroundColor: '#f9fafb', borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, marginBottom: 8 },
  datePickerTxt:   { fontSize: 13, color: '#111', fontWeight: '500' },

  btnPrimary:      { backgroundColor: '#1d4ed8', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 },
  btnPrimaryLong:  { backgroundColor: '#1d4ed8', paddingVertical: 12, borderRadius: 8, alignItems: 'center' },
  btnTxt:          { color: '#fff', fontWeight: '600', fontSize: 12 },
  btnTxtLong:      { color: '#fff', fontWeight: '700', fontSize: 14 },
  inlineBtn:       { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 },
  btnSuccess:      { backgroundColor: '#16a34a' },
  btnDanger:       { backgroundColor: '#dc2626' },

  facilityGrid:    { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 10 },
  facilityCard:    { width: '22%', backgroundColor: '#f9fafb', borderWidth: 1.5, borderColor: '#e5e7eb', borderRadius: 10, padding: 8, alignItems: 'center' },
  facilityIcon:    { fontSize: 22, marginBottom: 4 },
  facilityName:    { fontSize: 9, fontWeight: '700', color: '#374151', textAlign: 'center' },

  slotChip:        { backgroundColor: '#f3f4f6', borderRadius: 16, paddingHorizontal: 12, paddingVertical: 6, marginRight: 6, borderWidth: 1, borderColor: '#e5e7eb' },
  slotChipActive:  { backgroundColor: '#1d4ed8', borderColor: '#1d4ed8' },
  slotTxt:         { fontSize: 11, fontWeight: '600', color: '#374151' },

  announceCard:    { flexDirection: 'row', alignItems: 'flex-start', padding: 10, borderWidth: 1, borderColor: '#e5e7eb', borderRadius: 10, marginBottom: 8, backgroundColor: '#fff' },
  announceTitle:   { fontSize: 13, fontWeight: '700', color: '#111' },
  announceMsg:     { fontSize: 12, color: '#4b5563', marginTop: 3, lineHeight: 16 },
  announceMeta:    { fontSize: 10, color: '#9ca3af', marginTop: 3 },
  pinnedBadge:     { backgroundColor: '#6366f1', borderRadius: 3, paddingHorizontal: 4, paddingVertical: 1 },
  catBadge:        { borderRadius: 4, paddingHorizontal: 5, paddingVertical: 1 },
  catBadgeTxt:     { fontSize: 8, fontWeight: '700' },

  tabBar:          { height: 62, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#e5e7eb', paddingVertical: 4 },
  tabItem:         { paddingHorizontal: 14, alignItems: 'center', justifyContent: 'center', borderRadius: 8, marginHorizontal: 2 },
  tabItemActive:   { backgroundColor: '#eff6ff' },
  tabIcon:         { fontSize: 16 },
  tabLabel:        { fontSize: 10, fontWeight: '600', color: '#6b7280', marginTop: 1 },

  overlay:         { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 18 },
  modalCard:       { backgroundColor: '#fff', borderRadius: 14, padding: 18, elevation: 5 },
  modalTitle:      { fontSize: 15, fontWeight: '700', color: '#111', marginBottom: 14 },
  modalBtn:        { flex: 1, paddingVertical: 10, borderRadius: 6, alignItems: 'center' },
});
