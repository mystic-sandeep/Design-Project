import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ScrollView, ActivityIndicator, Alert,
} from 'react-native';
import { COLORS } from '../constants/theme';
import { login } from '../api/client';

const roles = [
  { id: 'admin',    icon: '⚙️',  label: 'Admin'    },
  { id: 'guard',    icon: '🛡️',  label: 'Guard'    },
  { id: 'resident', icon: '🏠',  label: 'Resident' },
  { id: 'staff',    icon: '🔧',  label: 'Staff'    },
  { id: 'maid',     icon: '🧹',  label: 'Maid'     },
];

export default function LoginScreen({ navigation, onLoginSuccess }) {
  const [selectedRole, setSelectedRole] = useState('resident');
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Validation', 'Please enter your email and password.');
      return;
    }
    setLoading(true);
    try {
      const data = await login(email.trim(), password, selectedRole);
      if (data?.success) {

        onLoginSuccess?.(selectedRole);
      } else {
        Alert.alert('Login Failed', data?.error || 'Invalid credentials. Please try again.');
      }
    } catch (_) {
      Alert.alert('Error', 'Could not reach the server. Check your connection.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container} keyboardShouldPersistTaps="handled">
      <Text style={styles.title}>Welcome back</Text>
      <Text style={styles.subtitle}>Sign in to your Mygate account</Text>

      <View style={styles.form}>
        <Text style={styles.label}>EMAIL ADDRESS</Text>
        <TextInput
          style={styles.input}
          placeholder="your@email.com"
          placeholderTextColor="#9ca3af"
          value={email}
          onChangeText={setEmail}
          autoCapitalize="none"
          keyboardType="email-address"
        />

        <Text style={styles.label}>PASSWORD</Text>
        <TextInput
          style={styles.input}
          placeholder="Your password"
          placeholderTextColor="#9ca3af"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
        />

        <Text style={styles.label}>LOGIN AS</Text>
        <View style={styles.roleGrid}>
          {roles.map((role) => (
            <TouchableOpacity
              key={role.id}
              style={[styles.roleCard, selectedRole === role.id && styles.selectedCard]}
              onPress={() => setSelectedRole(role.id)}
            >
              <Text style={styles.roleIcon}>{role.icon}</Text>
              <Text style={styles.roleLabel}>{role.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity
          style={[styles.loginBtn, loading && styles.loginBtnDisabled]}
          onPress={handleLogin}
          disabled={loading}
        >
          {loading
            ? <ActivityIndicator color={COLORS.white} />
            : <Text style={styles.loginBtnText}>Login to Mygate</Text>
          }
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate('Register')} style={styles.registerLink}>
          <Text style={styles.registerText}>Don't have an account? Register →</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:       { flex: 1, backgroundColor: COLORS.white, padding: 20 },
  title:           { fontSize: 28, fontWeight: '800', color: COLORS.teal, marginTop: 40 },
  subtitle:        { fontSize: 14, color: COLORS.gray, marginBottom: 30 },
  form:            { marginBottom: 40 },
  label:           { fontSize: 12, fontWeight: '700', color: COLORS.gray, marginBottom: 8 },
  input: {
    borderWidth: 1.5, borderColor: '#e5e7eb', borderRadius: 10,
    padding: 12, marginBottom: 20, fontSize: 14, color: COLORS.dark,
  },
  roleGrid:        { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 25 },
  roleCard: {
    width: '30%', padding: 10, borderWidth: 1.5, borderColor: '#e5e7eb',
    borderRadius: 10, alignItems: 'center', marginBottom: 10,
  },
  selectedCard:    { borderColor: COLORS.teal, backgroundColor: '#e0f0f0' },
  roleIcon:        { fontSize: 20 },
  roleLabel:       { fontSize: 10, fontWeight: '600', marginTop: 5 },
  loginBtn:        { backgroundColor: COLORS.teal, padding: 15, borderRadius: 10, alignItems: 'center' },
  loginBtnDisabled:{ backgroundColor: COLORS.gray },
  loginBtnText:    { color: COLORS.white, fontWeight: '700', fontSize: 16 },
  registerLink:    { marginTop: 16, alignItems: 'center' },
  registerText:    { color: COLORS.teal, fontWeight: '600', textDecorationLine: 'underline' },
});
