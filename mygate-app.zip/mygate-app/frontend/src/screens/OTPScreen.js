import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import { COLORS } from '../constants/theme';

export default function OTPScreen({ route, navigation, onLoginSuccess: onLoginSuccessProp }) {
  const [otp, setOtp]         = useState('');
  const [loading, setLoading] = useState(false);

  const { role, onLoginSuccess: onLoginSuccessParam } = route.params || {};
  const onLoginSuccess = onLoginSuccessProp || onLoginSuccessParam;

  const verify = async () => {
    if (otp.length !== 6) {
      Alert.alert('Invalid OTP', 'Please enter a 6-digit OTP to continue.');
      return;
    }

    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      const validRoles = ['resident', 'guard', 'admin', 'maid', 'staff'];
      if (!role || !validRoles.includes(role)) {
        Alert.alert('Invalid Role', 'Please select a valid role before login.');
        return;
      }

      if (typeof onLoginSuccess === 'function') {
        onLoginSuccess(role);
      } else {

        const screenMap = {
          resident: 'ResidentDashboard',
          guard:    'GuardDashboard',
          admin:    'AdminDashboard',
          maid:     'MaidDashboard',
          staff:    'StaffDashboard',
        };
        navigation.replace(screenMap[role]);
      }
    }, 800);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Enter OTP</Text>
      <Text style={styles.subtitle}>A 6-digit code was sent to your phone</Text>
      <TextInput
        style={styles.input}
        maxLength={6}
        keyboardType="numeric"
        placeholder="6-digit code"
        placeholderTextColor="#9ca3af"
        onChangeText={setOtp}
        value={otp}
      />
      <TouchableOpacity style={styles.button} onPress={verify} disabled={loading}>
        {loading
          ? <ActivityIndicator color={COLORS.white} />
          : <Text style={styles.buttonText}>Verify</Text>
        }
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backLink}>
        <Text style={styles.backText}>← Go back</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container:  { flex: 1, backgroundColor: COLORS.navyDark, justifyContent: 'center', padding: 20 },
  title:      { color: COLORS.white, fontSize: 24, fontWeight: '800', textAlign: 'center', marginBottom: 6 },
  subtitle:   { color: COLORS.gray, fontSize: 13, textAlign: 'center', marginBottom: 30 },
  input: {
    backgroundColor: '#1e2a4a',
    color: COLORS.white,
    padding: 15,
    borderRadius: 8,
    fontSize: 22,
    letterSpacing: 6,
    textAlign: 'center',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: COLORS.navyLight,
  },
  button:     { backgroundColor: COLORS.success, paddingVertical: 15, borderRadius: 8, alignItems: 'center' },
  buttonText: { color: COLORS.white, fontWeight: '700', fontSize: 16 },
  backLink:   { marginTop: 20, alignItems: 'center' },
  backText:   { color: COLORS.gray, fontSize: 13 },
});
