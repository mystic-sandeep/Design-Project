import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { COLORS } from '../constants/theme';

export default function Header({ title = 'MyGate', showAvatar = false, onBack, onLogout }) {
  return (
    <View style={styles.container}>
      <View style={styles.left}>
        {onBack ? (
          <TouchableOpacity onPress={onBack} style={styles.iconBtn}>
            <Text style={styles.backArrow}>←</Text>
          </TouchableOpacity>
        ) : (
          <Text style={styles.logo}>🏠</Text>
        )}
      </View>
      <Text style={styles.title} numberOfLines={1}>{title}</Text>
      <View style={styles.right}>
        {onLogout ? (
          <TouchableOpacity onPress={onLogout} style={styles.iconBtn}>
            <Text style={styles.logoutText}>Logout</Text>
          </TouchableOpacity>
        ) : showAvatar ? (
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>A</Text>
          </View>
        ) : (
          <View style={styles.placeholder} />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.teal,
    paddingTop: 48,
    paddingBottom: 14,
    paddingHorizontal: 16,
  },
  left: { width: 40, alignItems: 'flex-start' },
  right: { width: 60, alignItems: 'flex-end' },
  title: {
    flex: 1,
    textAlign: 'center',
    fontSize: 16,
    fontWeight: '800',
    color: COLORS.white,
    letterSpacing: 0.5,
  },
  logo: { fontSize: 20 },
  backArrow: { fontSize: 22, color: COLORS.white, fontWeight: '700' },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: COLORS.yellow,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: { color: COLORS.dark, fontWeight: '800', fontSize: 14 },
  iconBtn: { padding: 4 },
  logoutText: { color: COLORS.yellow, fontSize: 12, fontWeight: '700' },
  placeholder: { width: 32 },
});
