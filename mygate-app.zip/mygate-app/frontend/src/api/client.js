import AsyncStorage from '@react-native-async-storage/async-storage';

const BASE_URL = process.env.API_BASE_URL || 'http://localhost:3000';

export const saveToken = async (token) => {
  try { await AsyncStorage.setItem('@mygate_token', token); } catch (_) {}
};

export const getToken = async () => {
  try { return await AsyncStorage.getItem('@mygate_token'); } catch (_) { return null; }
};

export const clearToken = async () => {
  try { await AsyncStorage.removeItem('@mygate_token'); } catch (_) {}
};

export const apiFetch = async (url, options = {}) => {
  try {
    const token = await getToken();
    const headers = {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    };

    const response = await fetch(`${BASE_URL}${url}`, { ...options, headers });

    if (!response.ok) {
      const errorBody = await response.json().catch(() => ({}));
      return { success: false, status: response.status, ...errorBody };
    }

    return await response.json();
  } catch (_) {
    return null;
  }
};

export const login = async (email, password, role = 'resident') => {
  const data = await apiFetch('/api/v2/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password, role }),
  });
  if (data?.success && data?.token) {
    await saveToken(data.token);

    if (data.user) {
      try {
        await AsyncStorage.setItem('@mygate_name',      data.user.name      || data.user.email || email);
        await AsyncStorage.setItem('@mygate_email',     data.user.email     || email);
        await AsyncStorage.setItem('@mygate_apartment', data.user.apartment || data.user.flat || '');
        await AsyncStorage.setItem('@mygate_role',      data.user.role      || role);
      } catch (_) {}
    }
  }
  return data;
};

export const logout = async () => {
  await clearToken();
};
