# MyGate Fullstack — React Native App + Node.js Backend

## Architecture
```
React Native App (port 8081/Metro)
        ↓  HTTP + Socket.IO
Node.js Backend  (port 3000)       ← this repo
        ↓  HTTP proxy
Spring Boot Backend (port 8080)    ← MyGate website repo
        ↓
H2 Database
```

## Prerequisites
- Node.js >= 18
- Java JDK 17 or 21
- Android Studio + emulator (Pixel_6_API_34)
- Maven (for Spring Boot)

## Quick Start

### Step 1 — Install dependencies
```bash
npm install
npm run install:all
```

### Step 2 — Start Spring Boot (separate terminal, from MyGate/mygate_fixed/backend)
```bash
mvn spring-boot:run
```
Website available at: http://localhost:8080/admin.html

### Step 3 — Start Node backend
```bash
npm run backend:dev
```
You should see: System token obtained — sync service active

### Step 4 — Launch Android emulator (separate terminal)
```bash
C:\Users\VAISH\AppData\Local\Android\Sdk\emulator\emulator.exe -avd Pixel_6_API_34
```

### Step 5 — Run React Native app (separate terminal)
```bash
npm run frontend:android
```

## Run everything at once (backend + metro)
```bash
npm start
```

## Folder structure
```
mygate-fullstack/
├── backend/          ← Node.js + Express + Socket.IO
│   ├── src/
│   │   ├── server.js
│   │   ├── config/
│   │   ├── middleware/
│   │   ├── routes/
│   │   └── services/
│   ├── .env
│   └── package.json
├── frontend/         ← React Native 0.85
│   ├── src/
│   │   ├── api/client.js       ← change BASE_URL here for device
│   │   ├── navigation/
│   │   ├── screens/
│   │   └── components/
│   └── android/
│       └── gradle/wrapper/gradle-wrapper.properties  ← gradle-8.13-bin.zip
└── package.json      ← root workspace
```

## API BASE_URL (frontend/src/api/client.js)
- Android emulator: `http://10.0.2.2:3000`  ← default
- iOS simulator: `http://localhost:3000`
- Physical device: `http://YOUR_LAN_IP:3000`

## Test credentials (from Spring Boot data.sql)
| Role     | Email                  | Password  |
|----------|------------------------|-----------|
| Admin    | admin@mygate.com       | admin123  |
| Guard    | guard@mygate.com       | guard123  |
| Resident | resident@mygate.com    | res123    |
| Staff    | staff@mygate.com       | staff123  |
| Maid     | maid@mygate.com        | maid123   |
