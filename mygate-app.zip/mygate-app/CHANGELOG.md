# MyGate App – Bug Fix Changelog

## Fixes Applied (App-Specific)

### 1. Maid OTP Goes to Resident (Not Admin)
**File:** `frontend/src/screens/dashboards/ResidentDashboard.js`

- `handleBookMaid()` was creating a Task without `otpRecipient` — backend defaulted to `'admin'`
- Fixed: taskBody now includes `otpRecipient: 'resident'`

### 2. Complaint Filing Uses Shared Backend DB
**File:** `frontend/src/screens/dashboards/ResidentDashboard.js`

- `handleFileComplaint()` now calls `POST /api/v2/complaints` (shared Spring Boot endpoint)
- Complaints now persist in the H2 database, visible on the admin web dashboard and app admin dashboard
- Complaint object now includes `status: 'open'` field

### 3. Admin Dashboard Now Shows Complaints
**File:** `frontend/src/screens/dashboards/AdminDashboard.js`

- Added `complaints` state and `loadComplaints()` function calling `GET /api/v2/complaints`
- `loadDashboardData()` now includes `loadComplaints()` in the parallel load
- Added `resolveComplaint(id)` calling `PUT /api/v2/complaints/{id}/resolve`
- Added Resident Complaints card in the ScrollView with status badges and Resolve buttons
- Added complaint item styles to StyleSheet

### 4. New Node.js Backend Route: `/api/v2/complaints`
**New file:** `backend/src/routes/complaints.js`
**Updated files:** `backend/src/server.js`, `backend/src/services/websiteClient.js`

- Added `complaints.js` route module (GET, POST, PUT resolve, DELETE)
- Registered route at `app.use('/api/v2/complaints', complaintRoutes)` in `server.js`
- Added `getComplaints`, `fileComplaintV2`, `resolveComplaint`, `deleteComplaint` to `websiteClient.js`
- All requests proxy through to Spring Boot `/api/v2/complaints` — same database as web

---

## Architecture: Same Backend, Same Database

```
React Native App
      |
      v
Node.js Proxy Backend (app/backend)
      |  forwards all requests to ->
      v
Spring Boot Backend :8080
      |
      v
H2 Database (shared — same data seen on web + app)
```
