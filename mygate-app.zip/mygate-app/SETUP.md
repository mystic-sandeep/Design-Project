# MyGate App

## Structure
- `backend/` — Node.js/Express app backend (port 3000)
- `frontend/` — React Native app (Expo)

## Requirements
- Website backend (Spring Boot) must be running on port 8080 first
- Node.js 18+
- React Native / Expo CLI

## Start Backend
```
cd backend
npm install
cp .env.example .env
npm start
```

## Start App
```
cd frontend
npm install
npx expo start
```
