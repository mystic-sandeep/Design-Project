package com.mygate.controller;

import com.mygate.dto.LoginRequest;
import com.mygate.enums.Role;
import com.mygate.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private JwtUtil jwtUtil;

    private static final Map<String, String> OTP_STORE = new HashMap<>();

    // Hardcoded users for demo
    private static final Map<String, String[]> USERS = new HashMap<>();
    static {
        USERS.put("admin@mygate.com",    new String[]{"admin123",    "Admin User",     "A-001"});
        USERS.put("guard@mygate.com",    new String[]{"guard123",    "Security Guard", "G-001"});
        USERS.put("resident@mygate.com", new String[]{"resident123", "John Resident",  "B-202"});
    }

    @PostMapping("/send-otp")
    public ResponseEntity<Map<String, Object>> sendOtp(@RequestBody Map<String, String> request) {
        String phone = request.get("phoneNumber");
        if (phone == null || phone.length() != 10) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "error", "Invalid phone number"));
        }

        String otp = String.valueOf((int)(Math.random() * 900000) + 100000);
        OTP_STORE.put(phone, otp);

        // This is where you find the OTP!
        System.out.println("\n[BACKEND LOG] OTP for " + phone + " = " + otp + "\n");

        return ResponseEntity.ok(Map.of("success", true, "message", "OTP sent"));
    } // Ensure this brace is present!

    @PostMapping("/verify-otp")
    public ResponseEntity<Map<String, Object>> verifyOtp(@RequestBody Map<String, String> request) {
        String phone = request.get("phoneNumber");
        String otp   = request.get("otp");

        if (!OTP_STORE.containsKey(phone) || !OTP_STORE.get(phone).equals(otp)) {
            return ResponseEntity.status(401).body(Map.of("success", false, "error", "Invalid OTP"));
        }

        OTP_STORE.remove(phone);
        String token = jwtUtil.generateToken(phone, phone, "resident");

        return ResponseEntity.ok(Map.of("success", true, "token", token));
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody LoginRequest request) {
        // ... existing login logic ...
        return ResponseEntity.ok(Map.of("success", true));
    }
}
